"""Build-time ELF address helper (requires pyelftools)."""
from elftools.elf.elffile import ELFFile
class Image:
    def __init__(self,path):
        self.data=path.read_bytes()
        with path.open('rb') as f:
            e=ELFFile(f)
            self.segs=[dict(s.header) for s in e.iter_segments() if s.header['p_type']=='PT_LOAD']
            self.dynamic={t.entry.d_tag:t.entry.d_val for s in e.iter_segments()
                          if s.header['p_type']=='PT_DYNAMIC' for t in s.iter_tags()}
    def offset(self,va):
        for s in self.segs:
            if s['p_vaddr']<=va<s['p_vaddr']+s['p_filesz']:return s['p_offset']+va-s['p_vaddr']
        raise ValueError(hex(va))
    def va(self,off):
        for s in self.segs:
            if s['p_offset']<=off<s['p_offset']+s['p_filesz']:return s['p_vaddr']+off-s['p_offset']
        raise ValueError(hex(off))
