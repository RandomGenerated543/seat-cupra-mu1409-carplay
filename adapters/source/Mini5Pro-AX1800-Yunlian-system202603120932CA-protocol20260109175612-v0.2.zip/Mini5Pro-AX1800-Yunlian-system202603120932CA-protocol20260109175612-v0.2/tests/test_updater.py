import contextlib,hashlib,importlib.util,io,json,pathlib,sys,tempfile,unittest
from unittest.mock import patch
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P))
spec=importlib.util.spec_from_file_location('mini5_updater',P/'adapter-mini5.py')
u=importlib.util.module_from_spec(spec);spec.loader.exec_module(u)

IDENTITY='''Content-Type: text/html
system_version:202504171406CA
protocol_version:20250415195209
product_Model:v851se-yunlian-cp
custom:yunlian
platform:AX1800
'''
class Fake:
    def __init__(self,identity=IDENTITY,install='ota update ok\n',fail_upload=False):
        self.identity=identity;self.install=install;self.paths=[];self.fail_upload=fail_upload
    def request(self,path,data=None,ctype=None):
        self.paths.append(path)
        if path.endswith('getversion.cgi'):return self.identity
        if path.endswith('downfile.cgi'):
            if self.fail_upload:return 'file check fail'
            if b'.2"' in data:
                return 'Content-Type: text/html\n\nmd5_str is '+DIGEST+'\nresult is /tmp/test_mini5\nwrite data------success\nfinal frame\n'+DIGEST+'\nfile check success'
            return 'Content-Type: text/html\nwrite data------success'
        if 'submition.cgi' in path:return self.install
        if 'reboot.cgi' in path:return 'Content-Type: text/html'
        raise AssertionError(path)
DATA=b'x'*20500;DIGEST=hashlib.md5(DATA).hexdigest()
ROW={'md5':DIGEST,'upload_name':'test_mini5'}

class Tests(unittest.TestCase):
    def setUp(self):
        self.output=io.StringIO();self.sink=contextlib.redirect_stdout(self.output);self.sink.__enter__()
    def tearDown(self):self.sink.__exit__(None,None,None)
    def test_april_identity(self):self.assertEqual(u.probe(Fake())['platform'],'AX1800')
    def test_march_identity(self):u.probe(Fake(IDENTITY.replace('202504171406CA','202603120932CA')))
    def test_wrong_family(self):
        with self.assertRaises(u.Error):u.probe(Fake(IDENTITY.replace('AX1800','AX1800M')))
    def test_wrong_custom(self):
        with self.assertRaises(u.Error):u.probe(Fake(IDENTITY.replace('custom:yunlian','custom:yunlianC')))
    def test_wrong_product(self):
        with self.assertRaises(u.Error):u.probe(Fake(IDENTITY.replace('v851se-yunlian-cp','other')))
    def test_wrong_april_protocol(self):
        with self.assertRaises(u.Error):u.probe(Fake(IDENTITY.replace('20250415195209','20260905144506')))
    def test_wrong_system(self):
        with self.assertRaises(u.Error):u.probe(Fake(IDENTITY.replace('202504171406CA','202701010000CA')))
    def test_invalid_march_protocol(self):
        with self.assertRaises(u.Error):u.probe(Fake(IDENTITY.replace('202504171406CA','202603120932CA').replace('20250415195209','missing')))
    def test_recovery_allows_failed_app_only_on_known_system_family(self):
        u.probe(Fake(IDENTITY.replace('202504171406CA','202603120932CA').replace('20250415195209','missing')),recovery=True)
        with self.assertRaises(u.Error):u.probe(Fake(IDENTITY.replace('platform:AX1800','platform:AX1800M')),recovery=True)
    def test_check_only_never_installs(self):
        c=Fake();u.upload(c,ROW,DATA,False);self.assertFalse(any('submition' in p or 'reboot' in p for p in c.paths))
        self.assertIn('CHECK_ONLY=PASS',self.output.getvalue())
    def test_wrong_family_never_uploads(self):
        c=Fake(IDENTITY.replace('AX1800','AX1800M'))
        with self.assertRaises(u.Error):u.upload(c,ROW,DATA,True)
        self.assertEqual(len(c.paths),1)
    def test_upload_failure_never_commits(self):
        c=Fake(fail_upload=True)
        with self.assertRaises(u.Error) as error:u.upload(c,ROW,DATA,True)
        self.assertFalse(error.exception.install_requested)
        self.assertFalse(any('submition' in p for p in c.paths))
    def test_full_image_marker(self):u.install_ack('Content-Type: text/html\nota update ok\n')
    def test_app_tar_marker_refused(self):
        with self.assertRaises(u.Error):u.install_ack('success download')
    def test_missing_marker_refused(self):
        with self.assertRaises(u.Error):u.install_ack('ota: started')
    def test_duplicate_marker_refused(self):
        with self.assertRaises(u.Error):u.install_ack('ota update ok\nota update ok')
    def test_error_even_with_success_refused(self):
        with self.assertRaises(u.Error):u.install_ack('failed to check rootfs\nota update ok')
    def test_unknown_commit_never_reboots_or_retries(self):
        c=Fake(install='ota: started')
        with tempfile.TemporaryDirectory(dir=P/'tmp') as folder:
            with self.assertRaises(u.Error) as e:u.upload(c,ROW,DATA,True,folder)
            self.assertTrue(e.exception.install_requested)
            self.assertEqual(sum('submition' in p for p in c.paths),1)
            self.assertFalse(any('reboot' in p for p in c.paths))
            self.assertEqual(len(list(pathlib.Path(folder).glob('*.txt'))),1)
    def test_complete_then_reboot(self):
        c=Fake()
        with tempfile.TemporaryDirectory(dir=P/'tmp') as folder,patch.object(u.time,'sleep'):
            u.upload(c,ROW,DATA,True,folder)
        self.assertEqual(sum('submition' in p for p in c.paths),1)
        self.assertEqual(sum('reboot' in p for p in c.paths),1)
        self.assertIn('INSTALL_REPORTED_COMPLETE=1',self.output.getvalue())
    def test_bad_hash_reply(self):
        with self.assertRaises(u.Error):u.acknowledge('md5_str is '+'0'*32+'\nfile check success','upload','test_mini5',True,DIGEST)
    def test_known_unpadded_md5_reply(self):
        unpadded=''.join(format(b,'x') for b in bytes.fromhex(DIGEST))
        u.acknowledge('md5_str is '+DIGEST+'\n'+unpadded+'\nfile check success','upload','test_mini5',True,DIGEST)
    def test_public_host_refused(self):
        with self.assertRaises(u.Error):u.Client('8.8.8.8')
    def test_host_credentials_refused(self):
        with self.assertRaises(u.Error):u.Client('user@192.168.50.100')

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
    (P/'validation/UPDATER-TESTS.json').write_text(json.dumps({'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'network_requests':0,'device_writes':0},indent=2))
    sys.exit(0 if result.wasSuccessful() else 1)
