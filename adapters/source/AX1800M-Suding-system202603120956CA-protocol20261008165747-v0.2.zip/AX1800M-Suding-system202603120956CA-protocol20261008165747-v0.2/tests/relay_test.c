#define RELAY_HOST_TEST 1
#include "../src/relay.c"
#include <assert.h>
typedef struct Obj Obj;
struct Obj {int type,n;char text[128];void *key[64];int64_t val[64];Obj *item[64];};
static Obj pool[4096];static unsigned used;static int stock_calls,teardown_calls;
static void *last_request,*last_teardown,*info_root;
static void *platform_result;
static void *platform(void *s,unsigned flags,void *key,void *q,int *status){(void)s;(void)flags;(void)key;(void)q;if(status)*status=platform_result?0:-6727;return platform_result;}
static Obj *obj(int type){assert(used<4096);Obj *o=&pool[used++];memset(o,0,sizeof *o);o->type=type;return o;}
static const char *key_text(void *k){return (uintptr_t)k>0x10000000u?((Obj *)k)->text:0;}
static int equal_key(void *a,void *b){const char *sa=key_text(a),*sb=key_text(b);return a==b||(sa&&sb&&!strcmp(sa,sb));}
static int index_of(Obj *o,void *k){for(int i=0;i<o->n;i++)if(equal_key(o->key[i],k))return i;return -1;}
static void put(void *p,void *k,int64_t v){Obj *o=p;int i=index_of(o,k);if(i<0){assert(o->n<64);i=o->n++;o->key[i]=k;}o->val[i]=v;}
static void put_obj(void *p,void *k,void *v){put(p,k,(intptr_t)v);}
static int64_t get(void *p,void *k,int *e){if(e)*e=0;int i=index_of(p,k);return i<0?0:((Obj *)p)->val[i];}
static unsigned long type(void *p){return p?((Obj *)p)->type:0;}
static void *get_typed(void *p,void *k,unsigned long t,int *e){void *v=(void *)(intptr_t)get(p,k,e);return v&&type(v)==t?v:0;}
static unsigned long array_type(void){return 2;}
static unsigned long dict_type(void){return 1;}
static unsigned long string_type(void){return 3;}
static void *mkdict(void *a,long b,void *c,void *d){(void)a;(void)b;(void)c;(void)d;return obj(1);}
static void *mkarray(void *a,long b,void *c){(void)a;(void)b;(void)c;return obj(2);}
static void *mkstr(void *a,const char *s,unsigned enc){(void)a;(void)enc;Obj *o=obj(3);snprintf(o->text,sizeof o->text,"%s",s);return o;}
static int copystr(void *p,char *dst,long n,unsigned enc){(void)enc;return snprintf(dst,(size_t)n,"%s",((Obj *)p)->text)<n;}
static void *copy(void *a,long b,void *p){(void)a;(void)b;Obj *o=obj(1);*o=*(Obj *)p;return o;}
static long count(void *p){return ((Obj *)p)->n;}
static void *at(void *p,long i){return ((Obj *)p)->item[i];}
static void append(void *p,void *v){Obj *o=p;assert(o->n<64);o->item[o->n++]=v;}
static void release(void *p){(void)p;}
static void *keep(void *p){return p;}
static int add(void *r,void *d){append(get_typed(r,KEY_STREAMS,2,0),d);return 0;}
static int stock(void *s,void *r,void **out){(void)s;stock_calls++;last_request=r;Obj *d=obj(1),*a=obj(2),*in=get_typed(r,KEY_STREAMS,2,0);if(in)for(int i=0;i<in->n;i++)append(a,in->item[i]);put_obj(d,KEY_STREAMS,a);*out=d;return 0;}
static int teardown(void *s,void *a,void *c,unsigned char *d,void *e){(void)s;(void)c;(void)d;(void)e;teardown_calls++;last_teardown=a;return 0;}
static void *info(void *s,void *f,int *status){(void)s;(void)f;*status=0;return info_root;}
static Obj *stream(int t){Obj *d=obj(1);put(d,KEY_TYPE,t);put(d,K_CONNID,123);return d;}
static Obj *req(int a,int b){Obj *r=obj(1),*list=obj(2);if(a)append(list,stream(a));if(b)append(list,stream(b));put_obj(r,KEY_STREAMS,list);return r;}
static void set_num(Obj *d,const char *k,int n){put(d,mkstr(0,k,0),n);}
static void set_obj(Obj *d,const char *k,void *v){put_obj(d,mkstr(0,k,0),v);}
int main(void){
  native_info=&info_root;retain_cf=keep;
  stock_platform_copy=platform;
  cf_get_type_id=type;cf_dict_type_id=dict_type;cf_array_type_id=array_type;str_type=string_type;
  cf_dict_create_mutable=mkdict;cf_array_create_mutable=mkarray;str_create=mkstr;str_copy=copystr;
  cf_dict_get_typed=get_typed;cf_dict_get_int64=get;cf_dict_set_int64=put;cf_dict_set_value=put_obj;
  cf_dict_create_mutable_copy=copy;cf_array_count=count;cf_array_at=at;cf_array_append=append;cf_release=release;add_response_stream=add;orig_setup=stock;stock_teardown=teardown;stock_info=info;
  void *out=0;Obj *r=obj(1);assert(!relay_setup((void *)1,r,&out));assert(last_request==r);
  r=req(110,101);assert(!relay_setup((void *)1,r,&out));assert(last_request==r);
  r=req(110,111);assert(!relay_setup((void *)1,r,&out));
  Obj *a=get_typed(last_request,KEY_STREAMS,2,0);assert(a->n==1&&get(a->item[0],KEY_TYPE,0)==110);
  assert(((Obj *)get_typed(r,KEY_STREAMS,2,0))->n==2);
  a=get_typed(out,KEY_STREAMS,2,0);assert(a->n==2&&get(a->item[1],KEY_TYPE,0)==111&&get(a->item[1],KEY_DATAPORT,0)==19831);
  r=req(111,111);int before=stock_calls;assert(relay_setup((void *)1,r,&out)<0&&before==stock_calls);
  unsigned char done=1;Obj *list=obj(2);append(list,stream(110));assert(!relay_teardown((void *)1,list,0,&done,0));assert(last_teardown==list);
  list=obj(2);append(list,stream(111));before=teardown_calls;assert(!relay_teardown((void *)1,list,0,&done,0));assert(teardown_calls==before&&!done);
  list=obj(2);append(list,stream(110));append(list,stream(111));assert(!relay_teardown((void *)1,list,0,&done,0));assert(((Obj *)last_teardown)->n==1&&list->n==2);
  assert(!relay_teardown((void *)1,0,0,&done,0)&&!last_teardown);
  void *setup=(void *)SETUP_VA,*inf=(void *)INFO_VA,*td=(void *)TEARDOWN_VA,*prop=(void *)PLATFORM_COPY_VA;
  assert(bind_hooks(&setup,&inf,&td,&prop));assert(setup==(void *)&relay_setup&&prop==(void *)&relay_platform_copy);
  setup=(void *)SETUP_VA;inf=(void *)1;td=(void *)TEARDOWN_VA;prop=(void *)PLATFORM_COPY_VA;assert(!bind_hooks(&setup,&inf,&td,&prop)&&setup==(void *)SETUP_VA&&prop==(void *)PLATFORM_COPY_VA);
  assert(uuid_valid("e5f7a68d-7b0f-4305-984b-974f677a150b"));assert(!uuid_valid("b7e6-bad"));
  Obj *root=obj(1),*displays=obj(2),*display=obj(1);set_num(display,"type",111);set_num(display,"widthPixels",1010);set_num(display,"heightPixels",376);set_obj(display,"uuid",mkstr(0,"e5f7a68d-7b0f-4305-984b-974f677a150b",0));append(displays,display);set_obj(root,"displays",displays);
  char uuid[128];assert(profile_read(root,uuid)&&!strcmp(uuid,"e5f7a68d-7b0f-4305-984b-974f677a150b"));
  info_root=root;int status=0;assert(relay_info(0,0,&status)==root&&!strcmp(profile_uuid,uuid));
  Obj *features=dict_get(root,"enabledFeatures",2);assert(features&&features->n==2);relay_info(0,0,&status);assert(((Obj *)dict_get(root,"enabledFeatures",2))->n==2);
  Obj *initial=obj(1);assert(!relay_setup((void *)1,initial,&out));
  /* Model the real stock caller: property lookup overwrites response AFTER Setup. */
  void *feature_property=mkstr(0,"enabledFeatures",0);int feature_status=-1;
  Obj *ack=relay_platform_copy(0,1,feature_property,0,&feature_status);assert(ack&&ack->n==2&&!feature_status);
  set_obj(out,"enabledFeatures",ack);assert(dict_get(out,"enabledFeatures",2)==ack);
  assert(!strcmp(((Obj *)ack->item[0])->text,"altScreen"));
  assert(!strcmp(((Obj *)ack->item[1])->text,"viewAreas"));
  /* Profile can be populated during initial SETUP, before relay_info runs. */
  profile_uuid[0]=0;assert(!relay_setup((void *)1,initial,&out));
  assert(uuid_valid(profile_uuid));
  assert(relay_platform_copy(0,1,feature_property,0,0));
  Obj *response=obj(1),*oem_features=obj(2);append(oem_features,mkstr(0,"uiContext",0));set_obj(response,"enabledFeatures",oem_features);
  assert(advertise(response));Obj *combined=dict_get(response,"enabledFeatures",2);
  assert(combined->n==3&&!strcmp(combined->item[0]->text,"uiContext"));
  assert(advertise(response)&&((Obj *)dict_get(response,"enabledFeatures",2))->n==3);
  platform_result=oem_features;
  ack=relay_platform_copy(0,1,feature_property,0,&feature_status);assert(ack&&ack->n==3&&!strcmp(ack->item[0]->text,"uiContext"));
  void *other=mkstr(0,"unrelatedProperty",0);assert(relay_platform_copy(0,1,other,0,0)==oem_features);
  info_root=0;assert(relay_platform_copy(0,1,feature_property,0,0)==oem_features);info_root=root;platform_result=0;
  set_num(display,"widthPixels",0);assert(!profile_read(root,uuid));relay_info(0,0,&status);assert(!profile_uuid[0]);
  set_num(display,"widthPixels",1010);append(displays,display);assert(!profile_read(root,uuid));
  int sockets[2];assert(!socketpair(AF_UNIX,SOCK_STREAM,0,sockets));assert(!write_exact(sockets[0],"hello",5));char buf[5];assert(!read_exact(sockets[1],buf,5)&&!memcmp(buf,"hello",5));close(sockets[0]);assert(read_exact(sockets[1],buf,1)<0);close(sockets[1]);
  for(int i=0;i<200;i++) {
    Relay *r=calloc(1,sizeof *r);pthread_mutex_init(&r->mu,0);pthread_cond_init(&r->changed,0);
    r->refs=1;r->session=(void *)1;r->listener=r->phone=r->car=-1;
    current=r;hold(r);retire((void *)2);assert(current==r&&!stopped(r));
    retire((void *)1);assert(!current&&stopped(r));
    /* Late callback/worker references remain usable after current is retired. */
    assert(r->refs==1);hold(r);drop(r);assert(r->refs==1);drop(r);
  }
  puts("INDEPENDENT_HOST=PASS stock_main_audio=1 no_stream_setup=1 split_setup=1 teardown_isolation=1 input_immutable=1 dynamic_uuid=1 duplicates_rejected=1 transactional_hooks=1 socket_io=1 vehicle=UNTESTED");
  return 0;
}
