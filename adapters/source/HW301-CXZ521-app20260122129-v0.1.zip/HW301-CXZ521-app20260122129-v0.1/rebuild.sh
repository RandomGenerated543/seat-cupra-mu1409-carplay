#!/bin/sh
set -eu
cd "$(dirname "$0")"
D=${DOCKER:-/Applications/Docker.app/Contents/Resources/bin/docker}
export BUILDX_CONFIG="$PWD/.buildx"
mkdir -p stock/v129 build out
"$D" build --platform linux/amd64 -t cxz521-image-tools:20261029 .
"$D" run --rm --platform linux/amd64 -v "$PWD:/lab" cxz521-image-tools:20261029 sh -eu -c 'cd /lab/stock/v129; tar xf /lab/build-input/hw301_v129.tar; unsquashfs -d root app.img'
"$D" run --rm --platform linux/amd64 -v "$PWD:/lab" -w /lab -e PATH=/bin:/sbin:/usr/bin:/usr/sbin:/arm-linux-musleabihf/bin muslcc/x86_64:arm-linux-musleabihf@sha256:2abb44c0efdb11599b9d5d41474c6284e9bccd39a61e9d54427693280abe3bce sh -eu -c '
mkdir -p build/stub
printf "" > build/stub/empty.c
cc -shared -fPIC -o build/stub/libCoreUtilsReal.so build/stub/empty.c
cc -shared -fPIC -Os -marm -DCLUSTER_STEP=3 -DCLUSTER_ADVERT=3 -DSTEP_DECRYPT=1 -DCLUSTER_DIAG=1 -DCLUSTER_RGD=0 -o build/cluster_shim.so source/cluster_dual.c -Wl,-soname,libCoreUtils.so -Lbuild/stub -Wl,--no-as-needed -l:libCoreUtilsReal.so
strip build/cluster_shim.so'
"$D" run --rm --platform linux/amd64 -v "$PWD:/lab" cxz521-image-tools:20261029 python3 /lab/build_image.py
printf '%s\n' 'LOCAL_BUILD_COMPLETE device_writes=0 output=out/'
