#define SEAT_HOST_TEST 1
#include "../src/altscreen.c"
#include <assert.h>

typedef struct Obj Obj;
struct Obj { int type,n; void *key[8]; int64_t val[8]; Obj *item[8]; const char *text; };
static Obj pool[1024]; static int used,stock_calls,last_stock_count,last_stock_type;
static Obj *obj(int t) { Obj *o=&pool[used++];memset(o,0,sizeof *o);o->type=t;return o; }
static void *dmk(void *a,long b,void *c,void *d){(void)a;(void)b;(void)c;(void)d;return obj(1);}
static void *amk(void *a,long b,void *c){(void)a;(void)b;(void)c;return obj(2);}
static int idx(Obj *o,void *k){for(int i=0;i<o->n;i++)if(o->key[i]==k)return i;return -1;}
static void setv(void *p,void *k,int64_t v){Obj *o=p;int i=idx(o,k);if(i<0){i=o->n++;o->key[i]=k;}o->val[i]=v;}
static void seto(void *p,void *k,void *v){setv(p,k,(intptr_t)v);}
static int64_t getv(void *p,void *k,int *err){(void)err;Obj *o=p;int i=idx(o,k);return i<0?0:o->val[i];}
static void *geto(void *p,void *k,unsigned long t,int *e){(void)t;return (void *)(intptr_t)getv(p,k,e);}
static void *copy(void *a,long b,void *p){(void)a;(void)b;Obj *o=obj(1);*o=*(Obj *)p;return o;}
static long count(void *p){return ((Obj *)p)->n;}
static void *at(void *p,long i){return ((Obj *)p)->item[i];}
static void append(void *p,void *v){Obj *o=p;o->item[o->n++]=v;}
static void release(void *p){(void)p;}
static unsigned long tid(void){return 2;}
static unsigned long dictid(void){return 1;}
static unsigned long stringid(void){return 3;}
static unsigned long getid(void *p){return p?((Obj *)p)->type:0;}
static void *stringmk(void *a,const char *s,unsigned encoding){
  (void)a;(void)encoding;
  for(int i=0;i<used;i++)if(pool[i].type==3&&!strcmp(pool[i].text,s))return &pool[i];
  Obj *o=obj(3);o->text=s;return o;
}
static int equal(void *a,void *b){if(a==b)return 1;if(!a||!b)return 0;return ((Obj *)a)->type==3&&((Obj *)b)->type==3&&!strcmp(((Obj *)a)->text,((Obj *)b)->text);}
static int cstring(void *p,char *out,long n,unsigned e){(void)e;const char *s=((Obj *)p)->text;if(!s||(long)strlen(s)>=n)return 0;strcpy(out,s);return 1;}
static int add(void *r,void *entry){Obj *a=geto(r,KEY_STREAMS,2,0);append(a,entry);return 0;}
static void *last_stock_request;
static int stock(void *s,void *r,void **resp){(void)s;last_stock_request=r;stock_calls++;Obj *a=geto(r,KEY_STREAMS,2,0);last_stock_count=a?a->n:0;last_stock_type=a&&a->n?(int)getv(a->item[0],KEY_TYPE,0):0;Obj *d=obj(1),*out=obj(2);if(a)for(int i=0;i<a->n;i++)append(out,a->item[i]);seto(d,KEY_STREAMS,out);*resp=d;return 0;}
static Obj *stream(int type){Obj *s=obj(1);setv(s,KEY_TYPE,type);setv(s,K_CONNID,1234);return s;}
static Obj *request(int mixed){Obj *r=obj(1),*a=obj(2);append(a,stream(110));if(mixed)append(a,stream(111));seto(r,KEY_STREAMS,a);return r;}
int main(void){
  cf_dict_create_mutable=dmk;cf_array_create_mutable=amk;cf_dict_set_int64=setv;cf_dict_set_value=seto;cf_dict_get_int64=getv;cf_dict_get_typed=geto;cf_dict_create_mutable_copy=copy;cf_array_count=count;cf_array_at=at;cf_array_append=append;cf_release=release;cf_array_type_id=tid;orig_setup=stock;add_response_stream=add;g_cluster_started=1;
  cf_get_type_id=getid;cf_dict_type_id=dictid;mini_string_type=stringid;mini_string=stringmk;mini_equal=equal;mini_cstring=cstring;
  Obj *native=obj(1),*displays=obj(2),*descriptor=obj(1);void *native_ptr=native;
  mini_native_info=&native_ptr;
  setv(descriptor,KEY_TYPE,111);seto(descriptor,mini_key("uuid"),mini_key("actual-car-cluster-uuid"));append(displays,descriptor);seto(native,mini_key("displays"),displays);
  assert(mini_refresh_alt());assert(!strcmp(cluster_uuid,"actual-car-cluster-uuid"));
  Obj *offer=obj(1),*fa=obj(2),*original=obj(1),*ea=obj(2);
  append(fa,mini_key("altScreen"));append(fa,mini_key("viewAreas"));append(fa,mini_key("unknownFeature"));
  seto(offer,mini_key("features"),fa);append(ea,mini_key("stockFeature"));seto(original,mini_key("enabledFeatures"),ea);
  void *response=original;assert(mini_echo_features(offer,&response)==1);
  Obj *echo=geto(response,mini_key("enabledFeatures"),2,0);assert(echo->n==3);
  assert(mini_contains(echo,mini_key("altScreen"))&&mini_contains(echo,mini_key("viewAreas"))&&mini_contains(echo,mini_key("stockFeature")));
  assert(!mini_contains(echo,mini_key("unknownFeature")));assert(ea->n==1);assert(fa->n==3);
  assert(mini_echo_features(offer,&response)==0);assert(echo->n==3);
  void *saved_native=native_ptr;native_ptr=0;response=original;assert(mini_echo_features(offer,&response)==0&&response==original);native_ptr=saved_native;
  Obj *no_offer=obj(1);response=original;assert(mini_echo_features(no_offer,&response)==0&&response==original);
  Obj *r=request(1);void *resp=0;
  assert(shim_session_setup((void *)1,r,&resp)==0);assert(stock_calls==1&&last_stock_count==1&&last_stock_type==110);
  Obj *a=geto(resp,KEY_STREAMS,2,0);assert(a->n==2);assert(getv(a->item[1],KEY_TYPE,0)==111);assert(getv(a->item[1],KEY_DATAPORT,0)==19831);
  assert(((Obj *)geto(r,KEY_STREAMS,2,0))->n==2);assert(g_have_conn111&&g_conn111==1234);
  r=request(0);assert(shim_session_setup((void *)1,r,&resp)==0);assert(stock_calls==2&&last_stock_count==1);assert(last_stock_request==r);
  r=request(1);Obj *list=geto(r,KEY_STREAMS,2,0);append(list,stream(101));
  assert(shim_session_setup((void *)1,r,&resp)==0);assert(last_stock_count==2);
  a=geto(last_stock_request,KEY_STREAMS,2,0);assert(getv(a->item[1],KEY_TYPE,0)==101);
  r=request(1);list=geto(r,KEY_STREAMS,2,0);append(list,stream(111));int before=stock_calls;
  assert(shim_session_setup((void *)1,r,&resp)<0);assert(stock_calls==before);

  unsigned char idr[]={0,0,0,1,0x65},bad[]={0xff,0xff,0xff,0xff,0x65},zero[]={0,0,0,0,0x65};assert(seat_has_idr(idr,5));assert(!seat_has_idr(bad,5));assert(!seat_has_idr(zero,5));assert(!seat_has_idr(idr,4));
  puts("SEAT_DUAL_HOST=PASS main110_stock=1 auxiliary111_separate=1 input_request_unchanged=1 geometry=separate_test malformed_avcc_rejected=1 target_crypto_and_vehicle=UNTESTED");return 0;
}
