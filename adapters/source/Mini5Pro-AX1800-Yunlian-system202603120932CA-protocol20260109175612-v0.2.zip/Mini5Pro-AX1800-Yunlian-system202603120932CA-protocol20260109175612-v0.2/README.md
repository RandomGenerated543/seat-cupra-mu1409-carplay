## Required vehicle test and fresh phone pairing

A bench/computer may be used for upload and build verification. Functional acceptance MUST be tested in the actual compatible car, with its working head unit and Virtual Cockpit. A bench unit without the cockpit can produce misleading black-screen/no-map results.

After flashing reports completion and the documented reboot/power cycle is finished, remove the OLD adapter pairing from the iPhone: Settings > Bluetooth > the adapter > Forget This Device; also Settings > General > CarPlay > the matching adapter/car entry > Forget This Car if that entry exists. Do not erase unrelated pairings. Then connect the adapter in the parked car and pair it again as a new connection, with Bluetooth and Wi-Fi enabled, approving CarPlay. Old pairing/cache state can prevent correct connection after an update.

Verify centre-screen video/audio first, then cockpit maps, app-supported zoom, disconnect/reconnect and OEM return. A version string or retained build marker alone is not a car test. Fresh pairing does not cure wrong hardware/firmware. Collect logs before a restart/rollback if it fails.

# Mini 5 Pro: AX1800 / yunlian dual-display repair candidate v0.2

## v0.2 correction — read first

The supplied v0.1 adapter log repeatedly reported `altscreen GOT mismatch` and did not contain the successful MINI5_DUAL installation marker. The library constructor had run at some point but refused to attach the Setup hook. This does not establish the current process state or identify every cause of the main-screen reconnects.

Inspection found 47 October firmware address tokens, mostly literals with C `u` suffixes, left untranslated in v0.1 source. This was an error in the port. The v0.2 build maps them to the pinned March firmware, including Setup `0x4763f4` and its GOT slot `0x566434`. The original expected-pointer safety check remains active; it has not been bypassed. A new build guard rejects any remaining October tokens and verifies the exact stock GOT preimage. A host binding test accepts the March pointer and refuses the October pointer.

Three host C suites, 23 uploader tests and the complete 702-to-703-node filesystem audit passed locally. The kernel and stock March fallback are unchanged. The custom library's runtime loading, simultaneous centre/cockpit output, phone crypto and long-term reliability remain untested on the device. Do not mistake these local passes for a successful vehicle test.

Use the **entire new v0.2 folder**; do not copy only the uploader into v0.1. `dry-run` must identify candidate `mini5_yunlian_dual_v02.bin`. The new successful retained log marker is `MINI5_DUAL revision=mini5_yunlian_v02`. Old v0.1 validation is archived under `reference/v01-validation`; only the top-level `validation/` records describe this build.

**Highly experimental. Device execution and vehicle functionality are UNTESTED. Use at your own risk. Provided AS IS, without warranty; the authors and contributors accept no liability for damage or loss. This is not a universal Carlinkit firmware.**

This package contains a compiled custom candidate, an untouched vendor stock fallback, source, local test results, and a dedicated computer-side uploader. Nothing was flashed during preparation.

## Exact target

Owner's Mini 5 Pro identity:

```
platform:AX1800
custom:yunlian
product_Model:v851se-yunlian-cp
system_version:202504171406CA
protocol_version:20250415195209
```

**Not AX1800M/Suding, not HW301/CXZ521. Do not use either previous adapter's image or uploader.**

## What is built

The vendor currently offers `ax_202603120932` for this platform/custom pair. That **March 2026** kernel/rootfs image is the base for this pilot. The attempted historical April download names did not return firmware.

The candidate:

- Retains the normal Type 110 centre-screen path and other stock audio streams.
- Prevents the stock native-info filter from removing the car's secondary display.
- Echoes offered `altScreen` and `viewAreas` session features only when the car actually advertises a single Type 111 display with a usable UUID.
- Uses that advertised UUID, retains the supplied display/SafeArea metadata, and forwards validated video configuration geometry from the phone.
- Adds a separate Type 111 receiver and car-facing relay. It forwards compressed H.264 without decoding, resizing or re-encoding.
- Leaves vendor libraries, boot scripts, existing rootfs resources and metadata unchanged. The March vendor kernel is copied byte-for-byte into the candidate.

The firmware update writes **kernel and root filesystem**, not just the CarPlay application. Relative to your installed April firmware, this is also a system upgrade to the downloaded March base.

## The rollback limitation

`firmware/stock_ax_202603120932.bin` is the **untouched vendor March 2026 image**. It is bundled locally and its hash is pinned by the uploader. You do not need internet to use it.

**It does not restore April 2025.** We do not have that exact installed image. The fallback uses the adapter's HTTP updater, so its Wi-Fi/update service must remain reachable. It is not a verified unbrick method and does not back up the device's configuration, pairing, calibration or identity partitions. No automatic boot fallback has been demonstrated on this physical adapter.

If keeping the exact April installation is required, do not flash this pilot until that backup exists.

## Before installation

1. Extract the **entire ZIP** on the computer. Keep all `.py` files, `IMAGES.json`, and `firmware/` together.
2. Python 3.9+ is required. The uploader uses only Python's standard library; no pip packages are required for installation.
3. Power the adapter from a stable USB source and connect the computer to its Wi-Fi. Its usual management address is `192.168.50.100`. Use its actual saved Wi-Fi password.
4. The target car must already show cockpit CarPlay maps over a direct wired iPhone connection. This adapter package does not install or modify any head-unit or cockpit firmware.
5. Keep the adapter disconnected from the car during upload/installation. Run these commands on the computer, **not in the car's SSH shell**.

## Windows commands

Open PowerShell in the extracted package folder.

Local validation, followed by a read-only identity check:

```powershell
py adapter-mini5.py dry-run
py adapter-mini5.py probe
```

`dry-run` checks both images, including the vendor's kernel/rootfs MD5, payload MD5 and blockwise POSIX checksums. It makes no network requests.

Optional upload-only test:

```powershell
py adapter-mini5.py check-only
```

This uploads approximately 15.6 MB into the adapter's temporary cache and checks its acknowledgement. **It changes the cache and can interrupt a session.** It does not request firmware installation. `flash` uploads the image again and repeats the checks, so `check-only` is optional.

Install the experimental candidate:

```powershell
py adapter-mini5.py flash
```

The script prints that kernel/rootfs writes are about to be requested. Keep power connected throughout. Allow roughly **5–10 minutes**, depending on Wi-Fi and flash speed; this duration has not been measured on the target. The install request waits up to ten minutes.

Only the full-image updater's exact `ota update ok` marker is accepted as reported completion. After `INSTALL_REPORTED_COMPLETE=1`, the script requests a reboot. Allow about one minute, then reconnect to Wi-Fi:

```powershell
py adapter-mini5.py probe
```

The new system version should identify the March base. **The version alone does not verify the custom library, successful pairing or cockpit maps.**

If the request times out or reports `INSTALL_REQUESTED=1 result=UNKNOWN`, keep power connected, save the output and the reply log, and do not blindly retry or power-cycle. A lost HTTP reply does not prove that flashing stopped.

## First parked vehicle test

1. Connect the adapter to the actual target car. First establish centre-screen wireless CarPlay.
2. Start navigation, then check whether cockpit video appears.
3. Note centre-screen video, cockpit video, audio and controls separately. A main-only bench head unit cannot establish cockpit compatibility.
4. If necessary, pair the phone afresh; do not infer success from the adapter's loading screen.
5. Collect the adapter log bundle:

```powershell
py adapter-mini5.py logs
```

Files are saved in `logs/`. The custom retained-log marker is:

```
MINI5_DUAL revision=mini5_yunlian_v02
```

A retained marker proves only that the custom library loaded at some time. Check its associated session activity and actual visible output.

Known unqualified areas: proprietary session/HTTP structure layouts, actual loader execution, phone cryptography, reconnect/teardown, timing, dynamic car-to-phone cluster commands and wheel zoom. The car-facing relay currently supports legacy AES transport and explicitly refuses car-facing HomeKit mode. A first-session video pilot is the intended scope; full OEM-control parity is not claimed.

## Return to stock March firmware

If the adapter's HTTP service remains reachable:

```powershell
py adapter-mini5.py rollback
```

This uploads the bundled **stock March** image, validates it, invokes the full kernel/rootfs updater and requests a reboot only after reported completion. It accepts a failed/missing application protocol string during recovery, but still requires the known platform, custom, product model and April/March system family. It never bypasses those identity checks.

Keep power connected and follow the same completion/unknown-result handling as installation. If Wi-Fi/HTTP is unavailable, this rollback command cannot work; no physical recovery procedure is included.

## macOS / Linux

Use the same commands with `python3` instead of `py`, for example:

```sh
python3 adapter-mini5.py dry-run
python3 adapter-mini5.py probe
python3 adapter-mini5.py flash
python3 adapter-mini5.py logs
python3 adapter-mini5.py rollback
```

For a different private management IP, append `--host ADDRESS`. Public hosts, redirects and URLs containing credentials are refused.

## Local evidence and rebuilding

`validation/` records filesystem, loader, patch and uploader checks. Host tests passed with address/undefined-behaviour sanitizers for main/auxiliary separation, feature negotiation and video geometry. These do not substitute for execution on the adapter.

`reference/PORT-MAP.json` records 68 mapped references and two instruction patches for the March executable. Exported names, immutable CFString contents, MIPS GOT values and unique normalized private-helper sequences were checked. The October enabledFeatures/cornerMasks instruction patches were **not** transplanted into this older implementation.

Rebuilding needs Zig 0.13.0, Clang with sanitizers, Docker, and `requirements-build.txt`. A SquashFS tools image with LZO support is required. To create one:

```sh
docker build -f Dockerfile.squashfs -t mini5-squashfs .
```

Set `ZIG` to the Zig executable and `SQUASHFS_IMAGE=mini5-squashfs`, then run `python3 build.py`. `DOCKER` and `CLANG` can override executable locations. `build.py` extracts the pinned stock application from the bundled vendor image, compiles and tests the source, repacks the rootfs with OEM metadata, verifies the new OTA, and writes `IMAGES.json`. Run `python3 audit.py` and `python3 tests/test_updater.py` afterward. The build does not contact an adapter.

The source relay derives from OMKE's MIT-licensed project, pinned at `321191526ef26f98df87d85cd35d7597e5940ff1`, with the AX1800M October port as an intermediate reference. See `LICENSE-OMKE.txt` and `THIRD_PARTY_NOTICES.md`.
