"""HTTP transport and strict vendor chunk acknowledgement parser."""
import ipaddress,re,urllib.request,urllib.parse
class Error(Exception):
    def __init__(self,message,install_requested=False):
        super().__init__(message);self.install_requested=install_requested

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs): raise Error('redirect refused')

class Client:
    def __init__(self,host):
        u=urllib.parse.urlsplit('http://'+host)
        try: a=ipaddress.ip_address(u.hostname)
        except (TypeError,ValueError): raise Error('numeric private/local host required')
        if not (a.is_private or a.is_loopback) or u.username or u.password or u.path or u.query or u.fragment: raise Error('invalid local host')
        self.base='http://'+host
        self.timeout=60
        self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    def request(self,path,data=None,ctype=None):
        return self.request_raw(path,data,ctype).decode('utf-8','replace')
    def request_raw(self,path,data=None,ctype=None):
        req=urllib.request.Request(self.base+path,data=data)
        if ctype:req.add_header('Content-Type',ctype)
        try:
            with self.opener.open(req,timeout=self.timeout) as r:
                data=r.read(16*1024*1024+1)
                if len(data)>16*1024*1024:raise Error('response exceeds 16 MiB')
                return data
        except Exception as e:raise Error(str(e)) from e

def acknowledge(reply, stage, name, final=False, md5=None):
    """Accept known CGI chatter, never infer success from a substring.

    Some vendor CGIs print their Content-Type header inside the HTTP body.
    The first upload also prints temporary-file cleanup and its destination.
    Unknown/error lines or a missing final checksum acknowledgement stop us.
    """
    lines=[s.strip() for s in reply.splitlines() if s.strip()]
    if lines and lines[0].lower()=='content-type: text/html':lines.pop(0)
    if not lines:raise Error(stage+' empty reply')
    terminal=lines.pop()
    # Vendor diagnostics print each digest byte with %x rather than %02x.
    # This ambiguous display is accepted only alongside the exact full digest.
    unpadded=''.join(format(b,'x') for b in bytes.fromhex(md5)) if md5 else None
    full_md5_present=md5 is not None and 'md5_str is '+md5 in lines
    for line in lines:
        cleanup=stage=='upload' and re.fullmatch(r'successfully deleted file: /tmp/[/A-Za-z0-9_.-]+',line)
        destination=stage=='upload' and line=='result is /tmp/'+name
        last_write=stage=='upload' and final and line=='write data------success'
        checksum_context=stage=='upload' and final and md5 is not None and line in ('md5_str is '+md5,md5,'final frame')
        unpadded_context=stage=='upload' and final and full_md5_present and line==unpadded
        extracted=stage=='install' and line in ('sdDongle','libSdH.so','libSdHOct.so','libSdAuto.so','libSdCommon.so','libSdSampleRate.so','libSdUtils.so')
        extraction_command=stage=='install' and re.fullmatch(r'temp is tar -xvf\s+/tmp/'+re.escape(name)+r' -C /usr/data/lib/',line)
        if not (cleanup or destination or last_write or checksum_context or unpadded_context or extracted or extraction_command):raise Error(stage+' unknown/error line: '+repr(line))
    expected={'file check success'} if stage=='upload' and final else {'success','write data------success'} if stage=='upload' else {'success download'}
    if terminal not in expected:raise Error(stage+' rejected/unknown acknowledgement: '+repr(terminal))
    return terminal
