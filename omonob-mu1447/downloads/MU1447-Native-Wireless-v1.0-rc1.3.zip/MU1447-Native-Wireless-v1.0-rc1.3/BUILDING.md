# Source and rebuild notes

This archive includes the new Java patch tools, screen-ownership helper, native shim/hook source, exact binary deltas, installer and host tests. Shared upstream native dependencies remain binary dependencies; their complete implementation source is not recreated here. This is not a full OEM firmware source release.

Inputs used:

- `manual-ssh-mu1447/payload`: supplied shared wireless runtime, AID10.5-17PM receiver/profile and common jars.
- Public `VW_SKODA_SEAT_CarPlay_Maps_VC_FULL_MQB_Toolbox_V4.2A_v2.1.0-rc.7` MU1447/790 menu: preserved and extended with missing phone helpers.
- Exact extracted P4709/MU1447 firmware: used to pin native inputs and obtain the actual target touch class and J9 types. Full firmware images are not bundled.
- Existing working MU1447 wired-display/layout add-ons: baseline references only.

Build dependencies used locally: JDK21 for ASM tools; ASM/ASM-tree9.7; ARM QNX6.5 toolchain and sysroot; Python3; Unicorn for instruction tests. New runtime Java helper/probe code is compiled with Java8 bytecode and normalized by ASM to class version46 without frames; target compatibility is separately checked. ARM code uses ARMv7 soft-float ABI conventions.

`build_package.py` is the workspace assembler and records the developer's original input locations. It requires those inputs and the compiled/patched intermediate files; simply running it from this extracted SD package is not a complete independent build. Adapt the paths to your workspace. It preserves the supplied public menu's original entries, adds phone helpers, enumerates41 tracked destinations and pins native baselines.

Patch tool entry points:

```text
PatchOwnership original-CP.jar patched-CP.jar Mu1447ScreenOwnership.class
PatchOwnership original-Touch.jar ownership-Touch.jar
PatchOwnership --normalize compiled-helper.class
Patch1447NativeTouch exact-target-TouchInputDeviceImpl.class ownership-Touch.jar final-Touch.jar
PatchBootstrap original-Bootstrap.jar final-Bootstrap.jar
```

Run ASM tools with both `asm-9.7.jar` and `asm-tree-9.7.jar` on the host classpath. Include the normalized helper class in the patched CP jar. Compile `Wireless1447LinkCheck.java` as a separate normalized probe jar. The 15 phone helper classes come from the supplied profile menu and are added to, rather than replacing, the public rc.7 menu.

For receiver code, `source/receiver/zoom.c` and `zoom.ld` describe the fixed70 helper at VA0x1504a0. The original hash, exact branch/table/FPS edits, appended compiled payload and verifier expectations are recorded in `native/binary-patches.json`. Reproduce each pinned native artifact with:

```sh
python3 source/native/apply_binary_patches.py wcp_receiver ORIGINAL_RECEIVER OUTPUT_RECEIVER
python3 source/native/apply_binary_patches.py libomonob-wireless-maps.so ORIGINAL_MAP_HELPER OUTPUT_MAP_HELPER
python3 source/native/apply_binary_patches.py wireless-receiver-exec ORIGINAL_GUARD OUTPUT_GUARD
```

No keys are derived, embedded or patched by these changes. Tests under `source/` were run in the original development workspace against the matching input archives. Their paths must be adapted for another workspace. `VALIDATION.md` distinguishes mocked components, actual patched bytecode and emulated ARM code from the unperformed car tests.
