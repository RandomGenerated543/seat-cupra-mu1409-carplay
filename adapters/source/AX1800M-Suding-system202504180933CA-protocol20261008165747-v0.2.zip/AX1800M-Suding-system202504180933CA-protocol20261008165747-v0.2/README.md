## Required vehicle test and fresh phone pairing

A bench/computer may be used for upload and build verification. Functional acceptance MUST be tested in the actual compatible car, with its working head unit and Virtual Cockpit. A bench unit without the cockpit can produce misleading black-screen/no-map results.

After flashing reports completion and the documented reboot/power cycle is finished, remove the OLD adapter pairing from the iPhone: Settings > Bluetooth > the adapter > Forget This Device; also Settings > General > CarPlay > the matching adapter/car entry > Forget This Car if that entry exists. Do not erase unrelated pairings. Then connect the adapter in the parked car and pair it again as a new connection, with Bluetooth and Wi-Fi enabled, approving CarPlay. Old pairing/cache state can prevent correct connection after an update.

Verify centre-screen video/audio first, then cockpit maps, app-supported zoom, disconnect/reconnect and OEM return. A version string or retained build marker alone is not a car test. Fresh pairing does not cure wrong hardware/firmware. Collect logs before a restart/rollback if it fails.

# AX1800M / Suding — Leon MU1447 October pilot v0.2

**Experimental, not vehicle-verified. Use at your own risk, without warranty.** This package is for the tester reported AX1800M/Suding adapter and its original October application/system versions. No adapter/car was accessed by the agent during preparation.

## What changed

This candidate is built from the original **ax_202610081657** application that the owner restored and confirmed works for centre-screen CarPlay. The four vendor companion libraries are byte-for-byte unchanged. The main executable receives six checked instruction changes plus a small loader change, and loads libSdHOct.so. It does not downgrade to September.

The hook keeps Type 110 on the original vendor path and negotiates a separate Type 111 connection. Its video config headers validate/copy actual phone geometry rather than stamping an assumed canvas onto the video. The existing head-unit display dictionaries are retained, including the Leon's advertised SafeArea. No new SafeArea or zoomFactor is inserted by this package. Actual phone-facing metadata and visible framing still need checking on this adapter.

No decoding/resizing/re-encoding is added. No software or firmware on the MHI2/VC is included or changed.

## Confirmed target evidence

- SEAT Leon 5F MY2019 / Leon 300, MHI2_ER_SEG11_P4709 / MU1447.
- Existing M.I.B. carplay_maps_vc / omonob-derived mod; wired cockpit maps work.
- Actual Leon logs show main 800x480, auxiliary Type 111 at 1010x376, SafeArea 606x344, and sourceVersion950.7.1.
- Adapter: AX1800M, custom suding, system202504180933CA, protocol20261008165747. The uploader checks all four fields.
- Earlier black-screen testing was on a separate MHI2.5 bench head unit without the VC setup. It does not establish a failed Leon vehicle test. It remains a real failed bench test of the September candidate; its cause is unconfirmed.

## Windows: extract this entire NEW folder

Do not replace only the script in the old v0.1 folder: this version has a different image and IMAGES.json. Keep the new folder intact:

```text
AX1800M-Leon-MU1447-October-v0.2/
  adapter-october-r6.py
  IMAGES.json
  firmware/
```

Python 3.12+ is required. Open PowerShell/Terminal in this extracted folder. Run:

```powershell
py adapter-october-r6.py dry-run
```

The first line must be UPLOADER_REVISION=ax_october_uploader_r6, and it must finish DRY_RUN=PASS. This step does not access the network or device. If Python file association already works, `adapter-october-r6.py dry-run` is equivalent.

## Check the matching adapter

Connect the computer to the adapter's Wi-Fi. Use the password already established for this individual device; no universal password is assumed. Default address is the owner's 192.168.50.100. If the actual gateway differs, append `--host ACTUAL_IP` to commands. Do not point the uploader at the car's SSH address.

```powershell
py adapter-october-r6.py probe
py adapter-october-r6.py check-only
```

Expected finish: ADAPTER_CHECKSUM=PASS and CHECK_ONLY=PASS install_requested=0. Check-only uploads and checks the image but does not request installation/reboot. The vendor upload handler also deletes temporary runtime files, so it can interrupt an active session. Use it on the bench with the car disconnected. It is not a purely read-only operation.

## Explicit pilot installation

After a passing check, on the matching adapter:

```powershell
py adapter-october-r6.py flash
```

Allow approximately 2–5 minutes. Keep power connected. Expect INSTALL_REPORTED_COMPLETE=1; this means the CGI reported extracting the application files, not that either display works. The uploader then requests reboot. If it does not reboot, wait 30 seconds after reported completion and power-cycle it manually. If an error says INSTALL_REQUESTED=1/result=UNKNOWN, save the output rather than automatically repeating flash.

Reconnect Wi-Fi and run:

```powershell
py adapter-october-r6.py probe
py adapter-october-r6.py logs
```

**The protocol version stays 20261008165747 for both stock and custom October builds. Version alone cannot verify installation.** The new retained log marker is `AX_OCT_DUAL revision=ax_oct_v02`. The logs tool reports only whether that marker occurs in the retained bundle; it does not independently prove current process liveness. The old v0.1 marker is not counted as a v0.2 pass. Logs stay local and are not sent to the vendor.

## Actual Leon test

Use the confirmed Leon and leave its working M.I.B. mod installed. While parked, start a fresh adapter/phone session, verify centre-screen CarPlay first, then start navigation and check the cockpit. Independently observe both outputs; a log marker alone is not acceptance. Useful new hook lines include req stream type111, alt dataPort, cluster SETUP sent, cluster car dataPort, alt connected, alt config sent and increasing alt frames pushed. The car-side dataPort is negotiated, not assumed to be6031.

If either display fails, collect `py adapter-october-r6.py logs` before rollback if Wi-Fi is reachable, then restore stock. Keep the ordinary centre-screen result separate from cockpit output. Steering-wheel zoom, menu controls, reconnect and stock return each need independent checks.

## Restore original October application

The exact original stock update is included. If adapter Wi-Fi/web service remains reachable:

```powershell
py adapter-october-r6.py rollback
```

After reported completion, wait30 seconds, power-cycle/reconnect if needed and run probe. Protocol20261008165747 alone cannot distinguish stock from v0.2: verify ordinary wireless CarPlay visually. The stock executable does not load the hook. Unused custom .so files or retained logs can remain; this is an application rollback, not a full filesystem/configuration restore. If Wi-Fi does not return, this kit does not provide a proven physical recovery path. Do not use the Allwinner HW301 FEL tool on this MIPS adapter.

## Material limits

This remains a first-session pilot, not a qualified production release. Reconnect/teardown lifecycle is inherited from the public prototype; power-cycle before each initial qualification. Dynamic car-to-phone cluster command forwarding is not implemented. Existing wheel zoom may travel a stock route, but no SEAT wheel/control acceptance is claimed. The initial map URL matches the known M.I.B. core: maps:/car/instrumentcluster/map. The current car-facing relay explicitly declines HomeKit-mode transport if negotiated; the phone-facing relay supports the upstream ChaCha20-Poly1305 and legacy AES paths. Actual cryptography/ABI behaviour requires target logs/testing.

## Source and local validation

MIT-licensed base: OMKE/wireless-carplay-virtual-cockpit, commit321191526ef26f98df87d85cd35d7597e5940ff1. Source changes and reference source are included. Vendor binaries belong to their respective authors.

https://github.com/OMKE/wireless-carplay-virtual-cockpit

Porting used exact October exported symbols, byte-identical CFL constant objects, the unique October Setup GOT slot and instruction comparisons for private helpers. The six executable patch locations are checked against exact expected October words. It is not a generic offset shift from September.

Host checks passed: pinned vendor input hashes, MIPS cross-compilation, OEM library equality, six-site/loader byte-range audit, archive round-trip equality, AddressSanitizer/UndefinedBehaviorSanitizer session routing and geometry tests, and22 simulated uploader tests. Those tests do not execute the proprietary MIPS functions or establish actual target loader/session/video behaviour. Full reports are in validation/.

To rebuild, obtain Zig0.13.0, set ZIG to its executable and run Python3.12+ build.py. Supplied source and original October archive are sufficient once the compiler is installed/cached. The compiler target is mipsel-linux-gnueabihf.2.17 / mips32r2. The builder never flashes. It writes refreshed hashes to IMAGES.json; byte-identical rebuilds across tool versions/paths are not promised. Native test sources and updater tests are included.
