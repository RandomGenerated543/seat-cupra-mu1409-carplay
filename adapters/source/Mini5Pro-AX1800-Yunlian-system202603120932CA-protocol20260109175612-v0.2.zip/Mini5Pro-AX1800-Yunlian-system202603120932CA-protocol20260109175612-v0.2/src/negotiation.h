#ifndef MINI5_NEGOTIATION_H
#define MINI5_NEGOTIATION_H
/* AX1800/yunlian March 2026 only. No guessed fixed cockpit UUID/geometry. */
typedef void *(*mini_string_fn)(void *,const char *,unsigned);
typedef int (*mini_equal_fn)(void *,void *);
typedef int (*mini_cstring_fn)(void *,char *,long,unsigned);
static mini_string_fn mini_string=(mini_string_fn)0x4919a4u;
static mini_equal_fn mini_equal=(mini_equal_fn)0x4905c0u;
static mini_cstring_fn mini_cstring=(mini_cstring_fn)0x491c58u;
static type_id_fn mini_string_type=(type_id_fn)0x491658u;
static void **mini_native_info=(void **)0x56812cu; /* exported gFakeDict */
static void *mini_key(const char *s) {return mini_string(0,s,0x08000100u);}

static int mini_refresh_alt(void) {
  void *dict=mini_native_info?*mini_native_info:0;
  if(!dict || cf_get_type_id(dict)!=cf_dict_type_id())return 0;
  void *key=mini_key("displays");if(!key)return 0;
  void *a=cf_dict_get_typed(dict,key,cf_array_type_id(),0);cf_release(key);
  if(!a)return 0;
  long n=cf_array_count(a);if(n<1||n>16)return 0;
  void *selected=0;
  for(long i=0;i<n;i++) {
    void *d=cf_array_at(a,i);
    if(!d||cf_get_type_id(d)!=cf_dict_type_id())continue;
    if(cf_dict_get_int64(d,KEY_TYPE,0)==111) {
      if(selected)return 0;selected=d;
    }
  }
  if(!selected)return 0;
  key=mini_key("uuid");if(!key)return 0;
  /* The typed getter validates a CFString rather than interpreting a number. */
  void *uuid=cf_dict_get_typed(selected,key,mini_string_type(),0);cf_release(key);
  char value[sizeof cluster_uuid];memset(value,0,sizeof value);
  if(!uuid||!mini_cstring(uuid,value,sizeof value,0x08000100u)||!value[0])return 0;
  memcpy(cluster_uuid,value,sizeof cluster_uuid);
  return 1;
}

static int mini_contains(void *a,void *value) {
  long n=cf_array_count(a);
  for(long i=0;i<n;i++)if(mini_equal(cf_array_at(a,i),value))return 1;
  return 0;
}

static int mini_echo_features(void *req,void **response) {
  if(!response||!*response||!mini_refresh_alt())return 0;
  void *features=mini_key("features"),*enabled=mini_key("enabledFeatures");
  void *alt=mini_key("altScreen"),*views=mini_key("viewAreas");
  void *out=0,*copy=0;
  int changed=0,result=-1;
  if(!features||!enabled||!alt||!views)goto done;
  void *offered=cf_dict_get_typed(req,features,cf_array_type_id(),0);
  if(!offered){result=0;goto done;}
  long n=cf_array_count(offered);if(n<0||n>64)goto done;
  if(!mini_contains(offered,alt)){result=0;goto done;}
  void *existing=cf_dict_get_typed(*response,enabled,cf_array_type_id(),0);
  out=cf_array_create_mutable(0,0,arr_cb);if(!out)goto done;
  if(existing) {
    n=cf_array_count(existing);if(n<0||n>64)goto done;
    for(long i=0;i<n;i++)cf_array_append(out,cf_array_at(existing,i));
  }
  if(!mini_contains(out,alt)){cf_array_append(out,alt);changed=1;}
  if(mini_contains(offered,views)&&!mini_contains(out,views)){cf_array_append(out,views);changed=1;}
  if(!changed){result=0;goto done;}
  copy=cf_dict_create_mutable_copy(0,0,*response);if(!copy)goto done;
  cf_dict_set_value(copy,enabled,out);
  cf_release(*response);*response=copy;copy=0;
  result=1;
done:
  if(copy)cf_release(copy);if(out)cf_release(out);
  if(features)cf_release(features);if(enabled)cf_release(enabled);
  if(alt)cf_release(alt);if(views)cf_release(views);
  return result;
}
#endif
