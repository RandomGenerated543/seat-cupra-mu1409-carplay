#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct Obj {int kind,n;char keys[24][48];int64_t vals[24];struct Obj *items[8];} Obj;
typedef Obj *CFArrayRef;
typedef Obj *CFDictionaryRef;
typedef Obj *CFMutableDictionaryRef;
typedef Obj *CFMutableArrayRef;
typedef long CFIndex;
static void *p_array_callbacks;
static int fail_clone,fail_array;
static int p_CFGetTypeID(Obj *o){return o->kind;}
static int p_CFDictionaryGetTypeID(void){return 1;}
static int p_CFArrayGetCount(Obj *o){return o->n;}
static Obj *p_CFArrayGetValueAtIndex(Obj *o,long i){return o->items[i];}
static Obj *p_CFArrayCreateMutable(void *a,int b,void *c){Obj *o;(void)a;(void)b;(void)c;if(fail_array)return NULL;o=calloc(1,sizeof(*o));o->kind=2;return o;}
static Obj *p_CFArrayCreateMutableCopy(void *a,int b,Obj *s){Obj *o;(void)a;(void)b;o=malloc(sizeof(*o));*o=*s;return o;}
static Obj *dict_clone(Obj *s){Obj *o;if(fail_clone)return NULL;o=malloc(sizeof(*o));*o=*s;return o;}
static void p_CFArrayAppendValue(Obj *a,Obj *o){a->items[a->n++]=o;}
/* Test objects use arena lifetime; retain/release does not alter contents. */
static void p_CFRelease(Obj *o){(void)o;}
static void logf_u2(const char *s,...){(void)s;}
static int flight_dict_i64(Obj *d,const char *k,int64_t *v){int i;for(i=0;i<d->n;i++)if(!strcmp(d->keys[i],k)){*v=d->vals[i];return 1;}return 0;}
static void set_i64(Obj *d,const char *k,int64_t v){int i;for(i=0;i<d->n;i++)if(!strcmp(d->keys[i],k)){d->vals[i]=v;return;}strcpy(d->keys[d->n],k);d->vals[d->n++]=v;}
#include "menu-native/altscreen111-gen2/main_display_zoom.h"
static int64_t value(Obj *d,const char *key){int64_t v;assert(flight_dict_i64(d,key,&v));return v;}
int main(void){
 Obj main={.kind=1},second={.kind=1},arr={.kind=2,.n=2},before,*out,*alt;int64_t v;
 set_i64(&main,"type",110);set_i64(&main,"widthPixels",800);set_i64(&main,"heightPixels",480);
 set_i64(&main,"widthPhysical",174);set_i64(&main,"heightPhysical",104);set_i64(&main,"primaryInputDevice",2);
 arr.items[0]=&main;arr.items[1]=&second;before=main;
 out=main_display_zoom_copy(&arr);
 assert(out && out->n==2 && out->items[0]!=&main && out->items[1]==&second);
 assert(!memcmp(&main,&before,sizeof(main)) && value(out->items[0],"zoomFactor")==70);
 assert(value(out->items[0],"primaryInputDevice")==2 && value(out->items[0],"widthPhysical")==174);
 assert(value(out->items[0],"widthPixels")==800 && value(out->items[0],"heightPixels")==480);
 alt=dict_clone(&main);assert(!flight_dict_i64(alt,"zoomFactor",&v));
 set_i64(alt,"zoomFactor",150);assert(value(out->items[0],"zoomFactor")==70);
 assert(value(alt,"zoomFactor")==150);
 fail_clone=1;out=main_display_zoom_copy(&arr);assert(out->items[0]==&main);fail_clone=0;
 fail_array=1;out=main_display_zoom_copy(&arr);assert(out->items[0]==&main);fail_array=0;
 set_i64(&main,"widthPixels",1280);out=main_display_zoom_copy(&arr);assert(out->items[0]==&main);
 set_i64(&main,"widthPixels",800);set_i64(&main,"type",111);out=main_display_zoom_copy(&arr);assert(out->items[0]==&main);
 arr.n=0;assert(!main_display_zoom_copy(&arr));
 puts("MAIN_ZOOM_TEST=PASS isolation geometry input_metadata extra_display clone_failure array_failure wrong_target empty_array");return 0;
}
