# rc1.2 installer correction

Compare free-space values using decimal-aware awk rather than the signed32-bit shell integer comparison. The reported 3,123,281,920 free bytes now compares correctly against the 30,000,000-byte requirement. Numeric input validation is retained. Runtime payloads, target list and backup format are unchanged. A failed space preflight made no persistent changes.
