#!/usr/bin/env python3
"""Independent filesystem and loader checks; no device requests."""
from pathlib import Path
import hashlib,json,sys,types
P=Path(__file__).resolve().parent
local=P.parent/'tools'
if local.exists():sys.path.insert(0,str(local))
import lzokay
sys.modules['lzo']=types.SimpleNamespace(decompress=lambda src,header,size:lzokay.decompress(src,size))
from PySquashfsImage import SquashFsImage

def inventory(path):
    result={}
    with SquashFsImage.from_file(str(path)) as img:
        for i in img:
            row={'uid':i.uid,'gid':i.gid,'mode':i.mode,'time':str(i.time),'xattr':i.xattr}
            if i.is_file:
                # lzokay can return the entire output capacity, including
                # zero tail beyond the SquashFS inode's actual file length.
                data=i.read_bytes()[:i.size]
                assert len(data)==i.size
                row['size']=i.size;row['sha256']=hashlib.sha256(data).hexdigest()
            if i.is_symlink:row['symlink']=i.inode.__dict__['_symlink'].decode('utf-8','surrogateescape')
            if i.is_block_device or i.is_char_device:
                row['device']={k:v for k,v in i.inode.__dict__.items() if k not in ['_header','_uid','_gid','_mode']}
            result[i.path]=row
    return result

old=inventory(P/'build/rootfs-stock.squashfs');new=inventory(P/'build/rootfs-candidate.squashfs')
added=sorted(new.keys()-old.keys());removed=sorted(old.keys()-new.keys())
assert added==['/usr/lib/libSdHMini.so'] and not removed,(added,removed)
content=[];metadata=[];times=[]
for path,a in old.items():
    b=new[path]
    if a.get('sha256')!=b.get('sha256'):content.append(path)
    for k in ['uid','gid','mode','xattr','symlink','device']:
        if a.get(k)!=b.get(k):metadata.append((path,k,a.get(k),b.get(k)))
    if a['time']!=b['time']:times.append(path)
assert content==['/usr/bin/sdDongle'],content
assert not metadata,metadata
assert set(times)<=set(['/usr/bin/sdDongle','/usr/lib']),times
assert new['/usr/lib/libSdHMini.so']['uid']==0 and new['/usr/lib/libSdHMini.so']['mode']&0o777==0o755
report={'FILESYSTEM_AUDIT':'PASS','original_nodes':len(old),'candidate_nodes':len(new),'added':added,'removed':removed,
        'content_changed':content,'mode_owner_xattr_link_device_changes':metadata,'timestamps_changed':times,
        'target_execution':'UNTESTED','vehicle_functionality':'UNTESTED'}
(P/'validation/FILESYSTEM-AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
