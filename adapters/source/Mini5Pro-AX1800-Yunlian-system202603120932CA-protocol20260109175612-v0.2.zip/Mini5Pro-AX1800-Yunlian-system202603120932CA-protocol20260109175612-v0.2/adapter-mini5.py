#!/usr/bin/env python3
"""AX1800/yunlian Mini 5 Pro pilot. Run on your computer, never in car SSH."""
from pathlib import Path
import argparse,hashlib,io,json,re,sys,time,urllib.parse,uuid,zipfile
from http_transport import Client,Error,acknowledge
from ota_image import parse
P=Path(__file__).resolve().parent
REVISION='mini5_ax1800_yunlian_uploader_v2'
STOCK_SHA='ecf63d9e6d878a020fb7e204d9407c213d379eebee661816ae09de2ae9eac22e'
MARKER='MINI5_DUAL revision=mini5_yunlian_v02'

def image(kind):
    row=json.loads((P/'IMAGES.json').read_text())[kind]
    path=(P/row['file']).resolve()
    if P not in path.parents or not re.fullmatch(r'[A-Za-z0-9_]{1,64}',row['upload_name']):raise Error('unsafe manifest')
    blob=path.read_bytes()
    if len(blob)!=row['bytes'] or hashlib.sha256(blob).hexdigest()!=row['sha256'] or hashlib.md5(blob).hexdigest()!=row['md5']:raise Error('image hash mismatch')
    if kind=='rollback' and row['sha256']!=STOCK_SHA:raise Error('rollback is not pinned untouched vendor March image')
    parse(blob)
    return row,blob

def probe(c,recovery=False):
    text=c.request('/cgi-bin/getversion.cgi')
    info={k.strip():v.strip() for line in text.splitlines() if ':' in line for k,v in [line.split(':',1)]}
    if (info.get('platform'),info.get('custom'),info.get('product_Model'))!=('AX1800','yunlian','v851se-yunlian-cp'):raise Error('wrong adapter family; no upload')
    system,protocol=info.get('system_version'),info.get('protocol_version','')
    if system=='202504171406CA':
        if protocol!='20250415195209' and not recovery:raise Error('unmatched April application; no upload')
    elif system=='202603120932CA':
        if not re.fullmatch(r'\d{14}',protocol) and not recovery:raise Error('invalid March application identity; no upload')
    else:raise Error('unqualified system version; no upload')
    print('IDENTITY='+json.dumps({k:info.get(k) for k in ['platform','custom','product_Model','system_version','protocol_version']},sort_keys=True))
    print('EXACT_APRIL_ROLLBACK=UNAVAILABLE STOCK_FALLBACK=202603120932CA')
    return info

def install_ack(reply):
    lines=[x.strip() for x in reply.splitlines() if x.strip()]
    # This is the full-image updater's own terminal success, not the unrelated
    # AX1800M application's "success download"/tar acknowledgement.
    if lines.count('ota update ok')!=1:raise Error('missing unique full-image completion marker')
    if any(re.search(r'(?i)\b(failed|failure|error)\b|\bfail[! ]|ota version check not ok|ota: stoped (?!success)',s) for s in lines):
        raise Error('updater reported an error; inspect retained reply')

def upload(c,row,blob,commit=False,outdir=None,recovery=False):
    probe(c,recovery=recovery)
    count=(len(blob)+10239)//10240
    print('UPLOAD_SCOPE=TEMP_CACHE session_may_be_interrupted=1',flush=True)
    for index in range(count):
        suffix='.0' if index==0 else ':'+row['md5']+'.2' if index==count-1 else '.1'
        boundary=uuid.uuid4().hex
        body=(f'--{boundary}\r\nContent-Disposition: form-data; name="chunk"; filename="{row["upload_name"]+suffix}"\r\nContent-Type: application/octet-stream\r\n\r\n').encode()+blob[index*10240:(index+1)*10240]+f'\r\n--{boundary}--\r\n'.encode()
        reply=c.request('/cgi-bin/downfile.cgi',body,'multipart/form-data; boundary='+boundary)
        try:acknowledge(reply,'upload',row['upload_name'],final=index==count-1,md5=row['md5'])
        except Error as e:raise Error(f'chunk {index+1}/{count}: {e}; raw_reply={reply!r}') from e
        if index%100==0 or index==count-1:print(f'UPLOAD={index+1}/{count}',flush=True)
    print('ADAPTER_CHECKSUM=PASS',flush=True)
    if not commit:
        print('CHECK_ONLY=PASS install_requested=0 upload_cache_changed=1');return
    # All local checks and upload verification complete before the first
    # firmware write request. Never retry an ambiguous request automatically.
    dest=Path(outdir or 'logs');dest.mkdir(parents=True,exist_ok=True)
    log=dest/('mini5-install-'+uuid.uuid4().hex[:12]+'.txt')
    print('INSTALL=REQUESTING writes=kernel_and_rootfs keep_power_connected=1 timeout_minutes=10',flush=True)
    reply=None
    c.timeout=600
    try:
        reply=c.request('/cgi-bin/submition.cgi?filename='+urllib.parse.quote(row['upload_name'])+'&')
        log.write_text(reply,encoding='utf-8')
        install_ack(reply)
    except (Error,OSError) as e:
        raise Error('full-image install result UNKNOWN: '+str(e)+'; reply_log='+str(log.resolve())+'; keep power connected',install_requested=True) from e
    print('INSTALL_REPORTED_COMPLETE=1 runtime_verification=PENDING reply_log='+str(log.resolve()),flush=True)
    time.sleep(2)
    try:print('REBOOT_REPLY='+c.request('/cgi-bin/reboot.cgi').strip())
    except Error as e:print('REBOOT_REPLY_UNAVAILABLE='+str(e))
    print('Wait 60 seconds and reconnect. Verify centre CarPlay, then cockpit output. Version alone does not prove the hook.')

def logs(c,folder):
    dest=Path(folder);dest.mkdir(parents=True,exist_ok=True);tag='mini5-'+uuid.uuid4().hex[:12]
    (dest/(tag+'-version.txt')).write_text(c.request('/cgi-bin/getversion.cgi'),encoding='utf-8')
    data=c.request_raw('/cgi-bin/minizip.cgi?logID='+tag+'&');path=dest/(tag+'.bin');path.write_bytes(data)
    print('LOG_BUNDLE='+str(path.resolve())+' vendor_upload=0')
    if zipfile.is_zipfile(io.BytesIO(data)):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            entries=[n for n in z.namelist() if n.endswith('/altscreen.log') or n=='altscreen.log']
            for i,name in enumerate(entries):
                if z.getinfo(name).file_size>8*1024*1024:raise Error('oversized retained log')
                text=z.read(name).decode('utf-8','replace');(dest/(tag+f'-altscreen-{i}.log')).write_text(text,encoding='utf-8')
                print('RETAINED_BUILD_MARKER='+str(MARKER in text)+' current_process_liveness=UNCONFIRMED')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['dry-run','probe','check-only','flash','rollback','logs'])
    parser.add_argument('--host',default='192.168.50.100');parser.add_argument('--out',default='logs');args=parser.parse_args()
    print('UPLOADER_REVISION='+REVISION,flush=True)
    if args.command=='dry-run':
        for kind in ['candidate','rollback']:
            row,_=image(kind);print(f'IMAGE={kind} bytes={row["bytes"]} sha256={row["sha256"]}')
        print('DRY_RUN=PASS network_requests=0 device_writes=0 stock_fallback=MARCH_2026 exact_April_restore=0');return
    c=Client(args.host)
    if args.command=='probe':probe(c);return
    if args.command=='logs':logs(c,args.out);return
    kind='rollback' if args.command=='rollback' else 'candidate'
    row,blob=image(kind);upload(c,row,blob,args.command in ['flash','rollback'],args.out,recovery=args.command=='rollback')

if __name__=='__main__':
    try:main()
    except (Error,OSError,ValueError,KeyError) as e:
        print('MINI5=FAIL '+str(e),file=sys.stderr)
        if getattr(e,'install_requested',False):print('INSTALL_REQUESTED=1 result=UNKNOWN retain_power=1 no_retry=1',file=sys.stderr)
        else:print('INSTALL_REQUESTED=0 no firmware installation requested by this invocation',file=sys.stderr)
        sys.exit(2)
