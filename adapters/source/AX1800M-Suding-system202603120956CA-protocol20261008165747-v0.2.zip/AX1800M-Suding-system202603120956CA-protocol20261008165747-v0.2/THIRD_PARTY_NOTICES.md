# Provenance

The vendor executable and four companion libraries come from `ax_202610081657`, stock archive SHA-256 `13ca438ad4db00bbac0fa4650419df110bf17611a69525409261318a8bbade86`. Their original vendor rights apply.

The ABI declarations and geometry/AVCC helpers derive from this project's earlier October relay port and the MIT-licensed OMKE `wireless-carplay-virtual-cockpit` research, source reference commit `321191526ef26f98df87d85cd35d7597e5940ff1`. See LICENSE. Transport cryptography is performed by existing vendor routines; no authentication keys or certificates are distributed.

`src/relay.c` and this build/package logic implement the independent candidate. No previous dynamic111 implementation source/module is compiled or linked. Existing static binary-analysis findings are reused; this is not a clean-room claim.
