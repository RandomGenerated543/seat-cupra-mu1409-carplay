#define SEAT_HOST_TEST 1
#include "../src/altscreen.c"
#include <assert.h>
int main(void){
  void *slot=(void *)(uintptr_t)0x4763f4;
  assert(SETUP_VA==0x4763f4 && SETUP_GOT_VA==0x566434);
  assert(mini_bind_setup(&slot)==1 && slot==(void *)&shim_session_setup);
  slot=(void *)(uintptr_t)0x475668;
  assert(mini_bind_setup(&slot)==0 && slot==(void *)(uintptr_t)0x475668);
  assert(mini_bind_setup(NULL)==0);
  puts("MINI5_HOOK_BIND=PASS march_setup=1 october_rejected=1 unknown_preserved=1");
  return 0;
}
