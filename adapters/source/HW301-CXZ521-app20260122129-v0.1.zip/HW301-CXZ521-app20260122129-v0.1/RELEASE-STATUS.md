## Required vehicle test and fresh phone pairing

A bench/computer may be used for upload and build verification. Functional acceptance MUST be tested in the actual compatible car, with its working head unit and Virtual Cockpit. A bench unit without the cockpit can produce misleading black-screen/no-map results.

After flashing reports completion and the documented reboot/power cycle is finished, remove the OLD adapter pairing from the iPhone: Settings > Bluetooth > the adapter > Forget This Device; also Settings > General > CarPlay > the matching adapter/car entry > Forget This Car if that entry exists. Do not erase unrelated pairings. Then connect the adapter in the parked car and pair it again as a new connection, with Bluetooth and Wi-Fi enabled, approving CarPlay. Old pairing/cache state can prevent correct connection after an update.

Verify centre-screen video/audio first, then cockpit maps, app-supported zoom, disconnect/reconnect and OEM return. A version string or retained build marker alone is not a car test. Fresh pairing does not cure wrong hardware/firmware. Collect logs before a restart/rollback if it fails.

# HW301-CXZ521-app20260122129-v0.1

HIGHLY EXPERIMENTAL. USE AT YOUR OWN RISK. NO WARRANTY. Liability is excluded to the extent permitted by law.

Target: HW301 / CXZ521; original APP HW301_20250630126, system 20250320; candidate vendor v129 / HW301_20260122129

Owner reports working on 2026-10-30; not independently retested. Retained package validation describes what the builder checked at preparation time. An operator report is not universal hardware/firmware qualification.

Use this complete package and its own README, uploader/installer and rollback. Do not mix files from another model or version.

Public-copy changes affect labels, documentation and metadata only. Candidate/rollback payload bytes are retained. No private runtime logs, firmware extraction archives or SDKs are included.
