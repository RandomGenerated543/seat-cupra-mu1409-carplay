from pathlib import Path
import subprocess,json
p=Path('/test'); tool='arm-unknown-nto-qnx6.5.0eabi-readelf';out=[]
def read(v,*args):return subprocess.check_output([tool,*args,str(p/v/'payload/libmibr_carplay111.so')],text=True)
def symbols(v):return sorted({line.split()[-1] for line in read(v,'-Ws').splitlines() if ' UND ' in line and len(line.split())>=8})
def dependencies(v):return sorted(line.split('[',1)[1].split(']')[0] for line in read(v,'-d').splitlines() if '(NEEDED)' in line)
for a,b in [('baseline','candidate'),('legacy-baseline','legacy-candidate')]:
 assert symbols(a)==symbols(b),(a,b,'new unresolved symbols')
 assert dependencies(a)==dependencies(b),(a,b,'dependency drift')
 header=read(b,'-h');assert 'ELF32' in header and 'ARM' in header
 out.append({'baseline':a,'candidate':b,'undefined_symbols_unchanged':True,'dependencies':dependencies(b),'elf32_arm':True})
(p/'ABI-TESTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
