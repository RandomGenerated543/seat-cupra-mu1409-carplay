"""Pure Python validation of the vendor AX1800 kernel/rootfs OTA format."""
import hashlib,re
BLOCK=131072
TABLE=[]
for b in range(256):
    c=b<<24
    for _ in range(8):c=((c<<1)^0x04c11db7 if c&0x80000000 else c<<1)&0xffffffff
    TABLE.append(c)
def cksum(data):
    c=0
    for b in data:c=((c<<8)&0xffffffff)^TABLE[((c>>24)^b)&255]
    n=len(data)
    while n:c=((c<<8)&0xffffffff)^TABLE[((c>>24)^(n&255))&255];n>>=8
    return (~c)&0xffffffff
def crc(data):
    result=0
    for off in range(0,len(data),BLOCK):result^=cksum(data[off:off+BLOCK])
    return result
def parse(blob):
    if not BLOCK<len(blob)<=32*1024*1024:raise ValueError('OTA size invalid')
    header=blob[:BLOCK];end=header.find(b'\0')
    if end<0 or end>=2048 or any(header[end:]):raise ValueError('invalid OTA header padding')
    text=header[:end].decode('ascii')
    chunks=re.findall(r'img_type=(\w+)\nimg_name=([^\n]+)\nimg_size=(\d+)\nimg_md5=([0-9a-f]{32})\nimg_crc=(\d+)',text)
    if [(c[0],c[1]) for c in chunks]!=[('kernel','xImage'),('rootfs','rootfs.squashfs')]:raise ValueError('unexpected OTA image types')
    if not text.startswith('ota_version=0\n\n') or '\nbs_size=131072\n' not in text or '\ncheck_img=1\n' not in text:raise ValueError('unsupported OTA settings')
    offset=BLOCK;out=[]
    for typ,name,length,digest,checksum in chunks:
        length=int(length)
        if length<=0 or offset+length>len(blob):raise ValueError('invalid partition length')
        data=blob[offset:offset+length]
        if hashlib.md5(data).hexdigest()!=digest or crc(data)!=int(checksum):raise ValueError('partition checksum mismatch: '+name)
        if typ=='kernel' and data[:4]!=b'\x27\x05\x19\x56':raise ValueError('invalid kernel uImage')
        if typ=='rootfs' and data[:4]!=b'hsqs':raise ValueError('invalid rootfs')
        out.append((typ,name,data));offset+=length
    if offset!=len(blob):raise ValueError('trailing or missing OTA bytes')
    payload=re.search(r'\nota_img_packet_md5=([0-9a-f]{32})\n',text)
    if not payload or hashlib.md5(blob[BLOCK:]).hexdigest()!=payload[1]:raise ValueError('OTA payload checksum mismatch')
    return out
