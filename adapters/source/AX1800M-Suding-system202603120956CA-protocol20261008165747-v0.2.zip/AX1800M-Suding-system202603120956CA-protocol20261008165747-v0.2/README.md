## Required vehicle test and fresh phone pairing

A bench/computer may be used for upload and build verification. Functional acceptance MUST be tested in the actual compatible car, with its working head unit and Virtual Cockpit. A bench unit without the cockpit can produce misleading black-screen/no-map results.

After flashing reports completion and the documented reboot/power cycle is finished, remove the OLD adapter pairing from the iPhone: Settings > Bluetooth > the adapter > Forget This Device; also Settings > General > CarPlay > the matching adapter/car entry > Forget This Car if that entry exists. Do not erase unrelated pairings. Then connect the adapter in the parked car and pair it again as a new connection, with Bluetooth and Wi-Fi enabled, approving CarPlay. Old pairing/cache state can prevent correct connection after an update.

Verify centre-screen video/audio first, then cockpit maps, app-supported zoom, disconnect/reconnect and OEM return. A version string or retained build marker alone is not a car test. Fresh pairing does not cure wrong hardware/firmware. Collect logs before a restart/rollback if it fails.

# AX1800M independent dual-screen relay v0.2

**Highly experimental. Use at your own risk. No warranty or liability is accepted. This is a locally tested candidate, not a vehicle-confirmed fix.**

This is a separate implementation for `AX1800M / suding / v851se-yunlian-cp`, system `202603120956CA`. It starts from the exact October stock application (`ax_202610081657`), not the previous dynamic111 code. It does not include the previous feature, command, profile or video modules. It does reuse our prior October ABI analysis and the MIT-licensed OMKE transport research. It is not a clean-room implementation or an original January-firmware recovery.

## v0.2 correction: initial SETUP acknowledgement

The supplied v0.1 log shows 14 repetitions of initial SETUP, a valid Type-111 descriptor, then full teardown before any main or cockpit video SETUP. The owner confirms unmodified October stock worked on this exact adapter.

v0.1 added `altScreen`/`viewAreas` to phone-facing `/info` but omitted them from the separate initial SETUP response. v0.2 wraps the final `AirPlayReceiverServerPlatformCopyProperty` lookup of `enabledFeatures`, after the session SETUP function returns. The stock caller at `0x469a68` uses this result to overwrite response.enabledFeatures; editing only the earlier session response would not reliably survive. The wrapper preserves OEM features and appends the two supported capabilities only when a valid Type-111 HU descriptor is available. It refreshes that descriptor from the exact vendor `gFakeDict` cache, allowing initial SETUP before our phone-facing /info hook. OEM features are preserved and duplicate entries avoided. A new `stage=setup_features ... altScreen=1 viewAreas=1` marker identifies the returned array. This is a receiver-side response marker, not proof of phone acceptance. The missing-acknowledgement assertion fails against v0.1. The corrected suite also models the later stock property lookup and response overwrite, and passes.

This explains a concrete negotiation omission, not a proven complete cause of every black-screen symptom. Real adapter acceptance remains untested.

## What changed

- Centre-screen Type-110 video, audio and ordinary session SETUP execute through the vendor stock code.
- A single verified branch edit preserves the head unit's secondary display descriptor. A wrapper reads the actual Type-111 UUID from that descriptor; no SEAT/Skoda UUID, resolution or SafeArea is invented.
- `altScreen` and `viewAreas` are advertised only when a valid single Type-111 descriptor is present. Existing feature entries are preserved.
- A separate Type-111 worker forwards the source video configuration and compressed video. It decrypts/re-encrypts the transport using existing vendor routines; it does not decode/resize/re-encode video.
- Independent session references, bounded socket waits, reference-counted asynchronous replies and selective teardown prevent the auxiliary path from intentionally tearing down stock centre-screen video.
- Stage logs record constructor, hook binding, descriptor discovery, SETUP, phone connection, head-unit reply, video connection, config and forwarded frame counts. They do not record keys or video contents.
- Loader dependency bounds are updated in the existing mapping. No new virtual-memory segment is added.

These changes do not establish the cause of the previous black screen. Authentication, actual MIPS loader execution, simultaneous displays, controls, reconnects and compatibility of October application libraries with this March system still require an adapter test. A connected head unit with an already-working wired cockpit-map modification is required. HomeKit-mode HU transport is explicitly unsupported. This package is unrelated to the AX1800/yunlian Mini 5 Pro build.

## Firmware distinction

The original report was system `202603120956CA`, protocol `20260109175612`. No verified stock binary for that exact AX1800M/suding January application was found locally. Saved January downloads are seven-byte error bodies, not usable firmware.

The included rollback restores the **October application and its four companion libraries only**. It does not restore the original January application, kernel, root filesystem, pairing data or full flash. The vendor web updater must remain reachable for this recovery method. A reported version alone cannot prove that our library is running.

## Windows commands

Extract the entire folder, connect the PC to the adapter's Wi-Fi, and open PowerShell in this folder. Python 3 is required. These commands run on the PC, not the car's SSH terminal.

```powershell
py adapter.py dry-run
py adapter.py probe
```

The uploader refuses other platform/custom/model/system identities. January and October protocol strings are accepted for this specific reported system; this gate is not a compatibility guarantee. Default adapter address is `192.168.50.100`; override with `--host` if necessary.

The owner has now confirmed October stock works on the reported adapter. On another unqualified device, first establish a stock control: install the included October stock application and confirm ordinary centre-screen wireless CarPlay works after the restart.

```powershell
py adapter.py rollback
```

If stock October also shows a black screen, stop here and retain logs: our relay cannot fix an unqualified stock base. If stock works, test the independent candidate:

```powershell
py adapter.py flash
```

Keep power connected until `INSTALL_REPORTED_COMPLETE=1`. The uploader requests a reboot only after the recognized completion response. If the install result is UNKNOWN, retain power and save the output; do not automatically retry. After completed installation and restart, connect the phone and confirm centre-screen video/audio before cockpit maps. Allow approximately 3–5 minutes per upload/install, depending on the connection; reconnection and tests take additional time.

Save the resulting logs even if the display is black:

```powershell
py adapter.py logs --out logs-independent-v02
```

Look for `AX_INDEPENDENT v=2` in the extracted `altscreen.log`. An existing marker is retained evidence, not current-process liveness proof. Share the version text and extracted log first; the complete vendor bundle can contain personal device identifiers.

Return to October stock with:

```powershell
py adapter.py rollback
```

Mac equivalents use `python3` instead of `py`. No SSH credentials are used and no files are installed on MHI2 or the cockpit.

## Build and validation

Source is included. `build.py` requires Zig 0.13.0 (`ZIG`), a host C compiler (`CLANG`) and optionally `SDKROOT` on macOS. It accepts only the pinned October stock TAR and executable hashes, checks each original instruction/GOT pointer, builds the MIPS32r2 library, runs sanitizer-enabled host tests and creates a deterministic application TAR. The four vendor companion libraries remain byte-for-byte stock. `validation/` contains the build, patch and updater test results.

The host tests exercise the real wrappers with substituted vendor APIs, not a real adapter or phone. They cover ordinary/no-stream SETUP, mixed stream isolation, selective/full teardown, request immutability, dynamic UUID selection, duplicate/invalid descriptor rejection, transactional hook installation, socket I/O, relay-reference retirement and source-config geometry. Python updater tests use fake transport; they upload nothing to a real adapter. No vehicle acceptance is claimed.
