## Required vehicle test and fresh phone pairing

A bench/computer may be used for upload and build verification. Functional acceptance MUST be tested in the actual compatible car, with its working head unit and Virtual Cockpit. A bench unit without the cockpit can produce misleading black-screen/no-map results.

After flashing reports completion and the documented reboot/power cycle is finished, remove the OLD adapter pairing from the iPhone: Settings > Bluetooth > the adapter > Forget This Device; also Settings > General > CarPlay > the matching adapter/car entry > Forget This Car if that entry exists. Do not erase unrelated pairings. Then connect the adapter in the parked car and pair it again as a new connection, with Bluetooth and Wi-Fi enabled, approving CarPlay. Old pairing/cache state can prevent correct connection after an update.

Verify centre-screen video/audio first, then cockpit maps, app-supported zoom, disconnect/reconnect and OEM return. A version string or retained build marker alone is not a car test. Fresh pairing does not cure wrong hardware/firmware. Collect logs before a restart/rollback if it fails.

# Mini5Pro-AX1800-Yunlian-system202603120932CA-protocol20260109175612-v0.2

HIGHLY EXPERIMENTAL. USE AT YOUR OWN RISK. NO WARRANTY. Liability is excluded to the extent permitted by law.

Target: Mini 5 Pro / AX1800 / yunlian / v851se-yunlian-cp; original system 202504171406CA, protocol 20250415195209; full March base system 202603120932CA, protocol 20260109175612

Owner reports working on 2026-10-30; not independently retested. Retained package validation describes what the builder checked at preparation time. An operator report is not universal hardware/firmware qualification.

Use this complete package and its own README, uploader/installer and rollback. Do not mix files from another model or version.

Public-copy changes affect labels, documentation and metadata only. Candidate/rollback payload bytes are retained. No private runtime logs, firmware extraction archives or SDKs are included.
