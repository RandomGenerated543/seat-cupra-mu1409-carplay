# Third-party material

- Relay source derives from https://github.com/OMKE/wireless-carplay-virtual-cockpit at `321191526ef26f98df87d85cd35d7597e5940ff1`, MIT. Its license is retained as `LICENSE-OMKE.txt`. This Mini 5 Pro port adds target-specific mapping and negotiation, metadata validation, updater logic and packaging.
- The bundled stock AX1800/yunlian image and the vendor components retained in the candidate remain their respective owners' material. The OMKE MIT license does not relicense the vendor firmware. No Carlinkit endorsement is claimed.
- Public vendor source: POST `http://120.79.59.57:8080/device-web/upgrade/queryDeviceVersion` and `/device-web/upgrade/downLoad` with platform `AX1800`, custom `yunlian`, version `ax_202603120932`. Retained vendor metadata and matching MD5 establish download consistency, not cryptographic publisher authentication.
- Build/analysis dependencies are not embedded in the runtime: Zig 0.13.0, Clang, SquashFS tools, pyelftools, PySquashfsImage and lzokay. Their upstream licenses apply to those tools. The flash uploader itself requires only Python's standard library.

Highly experimental, provided AS IS without warranty. The stock fallback is March 2026, not the original April 2025 firmware, and is usable only while the adapter's updater is reachable. No on-device or vehicle acceptance has been established.
