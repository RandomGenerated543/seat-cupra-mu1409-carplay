"""Local image construction only. Never contacts or writes an adapter/car."""
from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,io
P=Path('/lab');stock=P/'stock/v129/root';root=P/'build/app-root';out=P/'out';out.mkdir(exist_ok=True)
expected={'bin/CPAAProxyEx':'5d6b652b7eeff8673b3428906fa59f57f1c63e5153dbb49eba3ef2e4fc6c47f0','lib/libAirPlay.so':'c319336788701928673380d0869647583c9fa48345e4cc25a0e86f28cf35b0e5','lib/libCoreUtils.so':'5d7cc40ee4638e17e0282a603be9022947507413bb79e0b39477d6fc2c803b61','lib/libiAP2Link.so':'04b6abbee63ccdaf8b2a799caf4e2941e8ebc04516f70dbff3f1f3462a57f44e'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,h in expected.items():assert sha(stock/n)==h,(n,'stock ABI drift')
if root.exists():shutil.rmtree(root)
shutil.copytree(stock,root,symlinks=True)
real=root/'lib/libCoreUtilsReal.so';shutil.copy(root/'lib/libCoreUtils.so',real)
subprocess.run(['patchelf','--set-soname','libCoreUtilsReal.so',str(real)],check=True)
shutil.copy(P/'build/cluster_shim.so',root/'lib/libCoreUtils.so')
build_id='seat-mu1409-cxz521-native-v0.1-20261029'
(root/'web/clbuild.txt').write_text(build_id+'\n')
meta={'build':build_id,'adapter_base':'HW301 stock v129 / CPAAProxyEx 20260122129','matching_reported_stock_v126':'20250630126','geometry':'copied from head unit; no Audi geometry constants','transport':'native independent type-111 SETUP and returned port','route_guidance_bridge':False,'diagnostics':True,'vehicle_tested':False}
(root/'web/seat-build.json').write_text(json.dumps(meta,indent=2)+'\n')
diff=[]
for f in root.rglob('*'):
 if f.is_file() and not f.is_symlink():
  n=str(f.relative_to(root));old=stock/n
  if not old.exists() or sha(f)!=sha(old):diff.append(n)
assert sorted(diff)==sorted(['lib/libCoreUtils.so','lib/libCoreUtilsReal.so','web/clbuild.txt','web/seat-build.json']),diff
for n in ['bin/CPAAProxyEx','bin/UpdateServer','lib/libAirPlay.so','lib/libiAP2Link.so']:assert sha(root/n)==sha(stock/n),n
img=out/'app.img'
subprocess.run(['mksquashfs',str(root),str(img),'-comp','xz','-b','262144','-noappend','-all-root','-no-xattrs','-no-progress'],check=True,stdout=(out/'mksquashfs.log').open('w'))
assert img.stat().st_size<=0x6c0000,'does not fit documented HW301 app partition'
md5=hashlib.md5(img.read_bytes()).hexdigest();(out/'appmd5sum.txt').write_text(md5+'\n')
tar=out/'cxz521-seat-mu1409-native-v0.1.tar'
with tarfile.open(tar,'w',format=tarfile.USTAR_FORMAT) as t:
 for name in ['app.img','appmd5sum.txt']:
  data=(out/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;info.uid=info.gid=0;t.addfile(info,io.BytesIO(data))
with tarfile.open(tar) as t:
 assert t.getnames()==['app.img','appmd5sum.txt']
 assert hashlib.md5(t.extractfile('app.img').read()).hexdigest()==t.extractfile('appmd5sum.txt').read().decode().strip()
verify=P/'build/roundtrip'
if verify.exists():shutil.rmtree(verify)
subprocess.run(['unsquashfs','-d',str(verify),str(img)],check=True,stdout=(out/'roundtrip.log').open('w'))
for f in root.rglob('*'):
 if f.is_file() and not f.is_symlink():assert sha(f)==sha(verify/f.relative_to(root)),f
report={**meta,'image_bytes':img.stat().st_size,'documented_app_partition_bytes':0x6c0000,'image_md5':md5,'ota_sha256':sha(tar),'changed_app_paths':diff,'pinned_ABI':expected,'roundtrip_all_file_hashes':True}
(out/'BUILD-REPORT.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
