#!/usr/bin/env python3
"""Offline build only. Never accesses an adapter or flashes a device."""
from pathlib import Path
import hashlib, json, os, re, shutil, struct, subprocess, sys
P=Path(__file__).resolve().parent
RESEARCH=P.parent
PROJECT=RESEARCH.parent.parent
# Local analysis installation is optional; a fresh build uses requirements-build.txt.
analysis=PROJECT/'work/ax1800m-firmware-research/analysis-tools'
if analysis.exists():sys.path.insert(0,str(analysis))
from elf_image import Image

def sha(b): return hashlib.sha256(b).hexdigest()
def md5(b): return hashlib.md5(b).hexdigest()
def run(argv,**kwargs):subprocess.run([str(x) for x in argv],check=True,**kwargs)

TABLE=[]
for b in range(256):
    c=b<<24
    for _ in range(8):c=((c<<1)^0x04c11db7 if c&0x80000000 else c<<1)&0xffffffff
    TABLE.append(c)
def cksum(data):
    c=0
    for b in data:c=((c<<8)&0xffffffff)^TABLE[((c>>24)^b)&255]
    n=len(data)
    while n:c=((c<<8)&0xffffffff)^TABLE[((c>>24)^(n&255))&255];n>>=8
    return (~c)&0xffffffff
def crc(data):
    result=0
    for off in range(0,len(data),131072):result^=cksum(data[off:off+131072])
    return result
def parse(blob):
    text=blob[:131072].split(b'\0',1)[0].decode()
    chunks=re.findall(r'img_type=(\w+)\nimg_name=([^\n]+)\nimg_size=(\d+)\nimg_md5=([0-9a-f]+)\nimg_crc=(\d+)',text)
    off=131072;out=[]
    for typ,name,size,want_md5,want_crc in chunks:
        size=int(size);data=blob[off:off+size]
        assert len(data)==size and md5(data)==want_md5 and crc(data)==int(want_crc),name
        out.append((typ,name,data));off+=size
    assert off==len(blob)
    assert md5(blob[131072:])==re.search(r'ota_img_packet_md5=(\w+)',text)[1]
    return out
def make_ota(kernel,rootfs):
    parts=[('kernel','xImage',kernel),('rootfs','rootfs.squashfs',rootfs)]
    text='ota_version=0\n\n'
    for typ,name,data in parts:
        text+=f'img_type={typ}\nimg_name={name}\nimg_size={len(data)}\nimg_md5={md5(data)}\nimg_crc={crc(data)}\n\n'
    payload=kernel+rootfs
    text+=f'check_img=1\n\nbs_size=131072\nota_img_packet_md5={md5(payload)}\n\n'
    header=text.encode();assert len(header)<2048
    return header+b'\0'*(131072-len(header))+payload
def patch_executable():
    stock=P/'build/stock-sdDongle'
    img=Image(stock);data=bytearray(img.data)
    assert sha(data)=='1340cc0b935995119412c0901dce72c5efc5f91ba762f6f2d7bf422c20a569cf'
    manifest=json.loads((P/'reference/PORT-MAP.json').read_text());ranges=[];patches=[]
    for patch in manifest['inline_patches']:
        va=int(patch['new'],16);o=img.offset(va);old=struct.unpack_from('<I',data,o)[0]
        assert old==int(patch['old_word'],16)
        if patch['old']=='0x469950':new=0x0320f809
        else:
            assert old==0x12000006
            new=0x10000006 # keep secondary display: bypass removal only
        struct.pack_into('<I',data,o,new);ranges.append((o,o+4));patches.append({'va':hex(va),'old':hex(old),'new':hex(new)})
    # Absolute DT_NEEDED avoids changing any existing search-path semantics.
    soname=b'/usr/lib/libSdHMini.so\0'
    with stock.open('rb') as f:
        from elftools.elf.elffile import ELFFile
        e=ELFFile(f);ro=dict(e.get_section_by_name('.rodata').header)
        dyn=next(s for s in e.iter_segments() if s.header['p_type']=='PT_DYNAMIC')
        dynoff,dynsz=dyn.header['p_offset'],dyn.header['p_filesz']
        assert not any(s.header['p_type']=='PT_GNU_RELRO' for s in e.iter_segments())
    cave=None
    for o in range(ro['sh_offset']+2,ro['sh_offset']+ro['sh_size']-len(soname)):
        if data[o-2:o+len(soname)+2]==b'\0'*(len(soname)+4):cave=o;break
    assert cave is not None
    data[cave:cave+len(soname)]=soname;ranges.append((cave,cave+len(soname)))
    strtab=img.dynamic['DT_STRTAB'];needed=img.va(cave)-strtab
    entries=[struct.unpack_from('<iI',data,dynoff+j*8) for j in range(dynsz//8)]
    end=next(j for j,pair in enumerate(entries) if pair[0]==0)
    assert end+1<len(entries) and entries[end+1]==(0,0)
    struct.pack_into('<iI',data,dynoff+end*8,1,needed);ranges.append((dynoff+end*8,dynoff+end*8+8))
    # Keep loader bounds consistent with the new absolute dependency string.
    strsz=next(j for j,pair in enumerate(entries) if pair[0]==10)
    struct.pack_into('<iI',data,dynoff+strsz*8,10,needed+len(soname));ranges.append((dynoff+strsz*8,dynoff+strsz*8+8))
    diff=[j for j,(a,b) in enumerate(zip(img.data,data)) if a!=b]
    assert len(data)==len(img.data) and all(any(lo<=j<hi for lo,hi in ranges) for j in diff)
    (P/'build/sdDongle').write_bytes(data)
    (P/'validation/ELF-PATCH.json').write_text(json.dumps({'stock_sha256':sha(img.data),'candidate_sha256':sha(data),
        'changed_bytes':len(diff),'allowed_ranges':ranges,'instruction_patches':patches,
        'needed':soname[:-1].decode(),'needed_string_va':hex(img.va(cave)),'no_RELRO':True},indent=2))

def main():
    for d in ['build','tmp','validation','firmware']:(P/d).mkdir(exist_ok=True)
    os.environ['TMPDIR']=str(P/'tmp');os.environ['ZIG_LOCAL_CACHE_DIR']=str(P/'build/zig-local');os.environ['ZIG_GLOBAL_CACHE_DIR']=str(P/'build/zig-global')
    rollback=(P/'firmware/stock_ax_202603120932.bin').read_bytes()
    assert sha(rollback)=='ecf63d9e6d878a020fb7e204d9407c213d379eebee661816ae09de2ae9eac22e'
    parts=parse(rollback);kernel,rootfs=parts[0][2],parts[1][2]
    assert cksum(b'123456789')==int(subprocess.check_output(['/usr/bin/cksum'],input=b'123456789').split()[0])
    (P/'build/rootfs-stock.squashfs').write_bytes(rootfs)
    docker=os.environ.get('DOCKER') or shutil.which('docker') or '/Applications/Docker.app/Contents/Resources/bin/docker'
    docker_image=os.environ.get('SQUASHFS_IMAGE','cxz521-image-tools:20261029')
    run([docker,'run','--rm','--platform','linux/amd64','--network','none','--mount',f'type=bind,source={P},target=/work',
         docker_image,'sh','-c','unsquashfs -cat /work/build/rootfs-stock.squashfs usr/bin/sdDongle > /work/build/stock-sdDongle'])
    from port_guard import verify
    (P/"validation/PORT-GUARD.json").write_text(json.dumps(verify(P/"build/stock-sdDongle"),indent=2)+"\n")
    patch_executable()
    local_zig=PROJECT/'work/ax1800m-firmware-research/tools/zig-macos-aarch64-0.13.0/zig'
    zig=os.environ.get('ZIG') or (str(local_zig) if local_zig.exists() else shutil.which('zig'))
    if not zig:raise SystemExit('Zig 0.13.0 is required; set ZIG to its executable')
    run([zig,'cc','-target','mipsel-linux-gnueabihf.2.17','-mcpu=mips32r2','-shared','-fPIC','-Os','-nostdlib',
         '-Wl,-soname,libSdHMini.so','-o',P/'build/libSdHMini.so',P/'src/altscreen.c','-lc','-lpthread'])
    clang=os.environ.get('CLANG') or ('/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang' if sys.platform=='darwin' else shutil.which('clang'))
    sdk='/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk'
    for name in ['session_test','geometry_test','hook_bind_test']:
        run([clang]+(['-isysroot',sdk] if sys.platform=='darwin' else [])+['-std=gnu11','-O1','-Wall','-Wextra','-Werror','-Wno-unused-function',
             '-DMSG_NOSIGNAL=0','-fsanitize=address,undefined',P/f'tests/{name}.c','-o',P/f'build/{name}'])
        run([P/f'build/{name}'])
    # Extraction/repacking inside an isolated container preserves device nodes,
    # symlinks and OEM modes/owners without creating host special files.
    shell='''set -eu
unsquashfs -no-progress -d /tmp/root /work/build/rootfs-stock.squashfs >/work/validation/unsquashfs.log
touch -r /tmp/root/usr/bin/sdDongle /tmp/sd-time
touch -r /tmp/root/usr/bin /tmp/bin-time
touch -r /tmp/root/usr/lib /tmp/lib-time
cp /work/build/sdDongle /tmp/root/usr/bin/sdDongle
cp /work/build/libSdHMini.so /tmp/root/usr/lib/libSdHMini.so
chmod 755 /tmp/root/usr/bin/sdDongle
chmod 755 /tmp/root/usr/lib/libSdHMini.so
touch -r /tmp/sd-time /tmp/root/usr/bin/sdDongle
touch -r /tmp/bin-time /tmp/root/usr/bin
touch -d @0 /tmp/root/usr/lib/libSdHMini.so
touch -r /tmp/lib-time /tmp/root/usr/lib
mksquashfs /tmp/root /work/build/rootfs-candidate.squashfs -noappend -comp lzo -b 131072 -processors 2 -no-progress -mkfs-time 0 >/work/validation/mksquashfs.log
'''
    run([docker,'run','--rm','--platform','linux/amd64','--network','none','--mount',f'type=bind,source={P},target=/work',
         docker_image,'sh','-c',shell])
    rebuilt=(P/'build/rootfs-candidate.squashfs').read_bytes()
    candidate=make_ota(kernel,rebuilt);parse(candidate)
    assert candidate[131072:131072+len(kernel)]==kernel
    out=P/'firmware/mini5_yunlian_dual_v02.bin';out.write_bytes(candidate)
    images={}
    for kind,path,name in [('candidate',out,'mini5_yunlian_dual_v02'),('rollback',P/'firmware/stock_ax_202603120932.bin','ax_202603120932')]:
        d=path.read_bytes();images[kind]={'file':str(path.relative_to(P)),'upload_name':name,'bytes':len(d),'sha256':sha(d),'md5':md5(d)}
    (P/'IMAGES.json').write_text(json.dumps(images,indent=2)+'\n')
    print(json.dumps({'BUILD':'PASS','images':images,'rollback_restores':'March 2026 stock; NOT April 2025',
                      'vehicle_tested':False,'target_execution_tested':False},indent=2))

if __name__=='__main__':main()
