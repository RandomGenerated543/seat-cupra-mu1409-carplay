#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PY=${ADAPTER_PYTHON:-"$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3"}
if [ ! -x "$PY" ]; then PY=$(command -v python3); fi
exec "$PY" "$ROOT/adapter.py" "$@"
