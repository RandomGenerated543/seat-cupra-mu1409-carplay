# Validation record — MU1447 integrated wireless v1.0-rc1.3

Date: 2026-11-19. Scope: local construction, static inspection, instruction emulation and host simulations. **No car was accessed and no hardware acceptance is recorded.**

| Check | Result | What it establishes |
|---|---|---|
| Actual patched Java classes under `-Xverify:all` | PASS | Camera borrow cannot be overridden by a stale visible canvas; touch falls through to OEM HMI while borrowed; independent take/borrow releases; session reset. |
| Java link probe against exact extracted MU1447 classes | PASS, 12 classes | Loads class metadata without initializing classes or invoking activators. The installation repeats this check on the unit's own J9. |
| Patched ARM receiver instructions in Unicorn | PASS | Fixed zoom70; original setter result and callee-saved registers retained; allocation/setter failure behavior; release balance; all five SEAT rectangles and adjacency links. API callees are emulated. |
| Native Bluetooth entry-point audit | PASS, 15 fingerprints | Existing bridge descriptor matches exact MU1447 executable entries. Does not establish full object ABI or actual Bluetooth behavior. |
| Receiver/library integrity guard | PASS | Embedded expected SHA-256 values updated to the exact modified receiver and map helper. Transport-library expectation retained. Hash checks are not disabled. |
| Continuous channel watcher with mocked interfaces | PASS | Continues beyond the old 240-second window; handles a later channel change; stable marker recovers; duplicate watcher suppressed; credentials unchanged/not logged. |
| Real installer in isolated host fixture | PASS, 10 cases | Check makes no persistent changes; install/receipt; repeated apply idempotence; exact restore with pairing sentinel retained; automatic rollback on late guard failure; partial transaction restore; refusal of unknown later edits and wrong native baseline; 19.5 MiB available RAM passes and insufficient RAM refuses without persistent writes. QNX executables and mount operations are mocked in this test. |
| Original public rc.7 menu preservation | PASS | Every original entry remains byte-identical inside merged menu. Fifteen missing phone-integration helper classes added. |
| Safe-area bounds | PASS | Every rectangle fits the 1010×376 frame; Center y=76, h=185; Left h=252. |
| Final manifest and ZIP round trip | PASS | All bytes covered by manifest; no `.DS_Store`, resource forks, old pilots or firmware dumps included. |
| On-car wireless video/audio/touch/calls/cameras/reconnect | **UNTESTED** | Cannot claim stable or bug-free until observed on the vehicle. |

## Backup manifest correction

The shipped native ARM manifest parser was executed in Unicorn with stubbed file/libc APIs. One-space separators are rejected; two-space separators and metadata paths pass; duplicates, traversal and missing final newline are rejected. The host fixture now enforces the same delimiter grammar and exercises verified preservation of an unfinished legacy backup. These checks do not activate any car service.

## Binary changes

- `btstack`, `connectionmanager`, stock `libairplay.so` and `lsd.jxe` are exact input identities only; the installer never replaces them.
- `libbtwcp.so` is the supplied upstream bridge, unchanged. A separate tiny QNX shim translates thread ID zero into `pthread_self()` before the bridge's thread bookkeeping.
- `wcp_receiver` has a pinned auxiliary descriptor hook, exact safe-area table edits and an auxiliary maximum-FPS instruction changed from60 to30.
- `libomonob-wireless-maps.so` retains native card selection and changes its request URLs to ETA=yes, preserving native alignment. The Off reference uses the full ETA-bearing `/map` URL.
- `wireless-receiver-exec` retains its integrity comparisons; only the two expected receiver/map-helper digests change.
- Touch patching uses the actual MU1447 stock outer input class, retains its OEM implementation and inserts forwarding at one touch-update entry. CP/SI startup is explicit in the bootstrap. Screen ownership is patched independently of canvas visibility.
- Existing wired `core.so`, both wired launcher copies, wired zoom library, media/artwork startup and existing user media files are not installer targets.

`source/native/binary-patches.json` contains pinned byte-level before/after deltas. `source/native/apply_binary_patches.py` reproduces them only for matching donor hashes. Original opaque upstream dependencies are not represented as newly authored source.
