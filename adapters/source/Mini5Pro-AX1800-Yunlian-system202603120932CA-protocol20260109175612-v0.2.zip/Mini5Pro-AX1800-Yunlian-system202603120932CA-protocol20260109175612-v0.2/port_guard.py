"""Reject unported October address tokens, including C integer suffixes."""
from pathlib import Path
import json,re,struct
P=Path(__file__).resolve().parent
TOKEN=re.compile(r'\b0x([0-9a-fA-F]+)([uUlL]*)\b')
def verify(stock=None):
    mapping={int(k,16):int(v,16) for k,v in json.loads((P/'reference/PORT-MAP.json').read_text())['mapping'].items()}
    source=(P/'src/altscreen.c').read_text()
    remaining=[hex(int(m[1],16)) for m in TOKEN.finditer(source) if int(m[1],16) in mapping]
    if remaining:raise ValueError('Unported October addresses: '+','.join(sorted(set(remaining))))
    setup=int(re.search(r'#define SETUP_VA (0x[0-9a-fA-F]+)',source)[1],16)
    got=int(re.search(r'#define SETUP_GOT_VA (0x[0-9a-fA-F]+)',source)[1],16)
    assert setup==mapping[0x475668] and got==mapping[0x56526c]
    if stock is not None:
        from elf_image import Image
        image=Image(stock)
        assert struct.unpack_from('<I',image.data,image.offset(got))[0]==setup,'March GOT does not point to mapped Setup'
    return {'status':'PORT_ADDRESS_GUARD=PASS','remaining_october_addresses':0,
            'setup_va':hex(setup),'setup_got_va':hex(got),'stock_got_preimage_verified':stock is not None}
if __name__=='__main__':
    import sys
    print(json.dumps(verify(Path(sys.argv[1]) if len(sys.argv)>1 else None),indent=2))
