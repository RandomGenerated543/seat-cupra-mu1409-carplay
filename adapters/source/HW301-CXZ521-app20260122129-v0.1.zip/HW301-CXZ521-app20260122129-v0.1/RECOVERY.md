# Recovery — bench USB only

Use web rollback first if the updater responds. Otherwise the reference HW301 supports Allwinner FEL recovery over USB. Included tools/xfel is a native Apple Silicon executable; help was tested, actual USB recovery was not. Intel Macs need a rebuilt tool.

The upstream procedure applies to **RSY03 V1.0 / V851S / 16 MiB SPI NOR**. Your PCB has not been inspected. Open the unplugged adapter and identify board, SoC and flash. Do not infer pin orientation from the case/FCC ID, or short an unidentified pin. Consult reference/UPSTREAM-README.md and the pinned upstream source in BUILD.md.

On the verified reference board only, upstream enters FEL by holding flash DO (pin 2) to ground during USB insertion, releasing after about two seconds. This is not an instruction to short pin 2 on an unverified board. Release before reading; use a data-capable USB connection.

From the kit folder on Mac, with the device already in FEL:

```sh
sh recovery.sh backup
```

This reads 16 MiB twice, requires identical reads and valid GPT CRCs, and checks the reference app partition offset/size. It writes nothing to the device. Keep both backups. A dump after failed OTA is not an original app backup, but retains individual regions. Different layouts are refused; do not override the offsets.

Replace FLASH-DUMP.bin with the actual verified filename printed above:

```sh
sh recovery.sh prepare --dump recovery/FLASH-DUMP.bin
```

This only constructs a local stock-v126 app image and preserves the dump's final erase-block tail. To explicitly write the app and verify readback:

```sh
sh recovery.sh restore --dump recovery/FLASH-DUMP.bin
```

It checks current GPT and fixed boot/rootfs/private regions against the dump before writing. This is a compatibility check, not cryptographic device identity. Only the app extent is written; bootloader, environment, private and UDISK partitions are not written. After readback PASS, boot and CarPlay still need testing. Unsupported hardware/electrical faults can prevent recovery.

Never write a downloaded full-device dump containing another adapter's identifiers. This kit includes no individual device keys or pairing data.
