#!/usr/bin/env python3
"""Offline address mapping. A match is evidence, not runtime qualification."""
from pathlib import Path
import json, re, struct, sys

R = Path(__file__).resolve().parent
PROJECT = R.parent.parent
sys.path.insert(0, str(PROJECT/'work/ax1800m-firmware-research/analysis-tools'))
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_MIPS, CS_MODE_MIPS32, CS_MODE_LITTLE_ENDIAN

class Image:
    def __init__(self, path):
        self.path = path
        self.data = path.read_bytes()
        with path.open('rb') as f:
            e = ELFFile(f)
            self.syms = {s.name: dict(s.entry) for s in e.get_section_by_name('.dynsym').iter_symbols()
                         if s.entry['st_shndx'] != 'SHN_UNDEF'}
            self.segs = [dict(s.header) for s in e.iter_segments() if s.header['p_type'] == 'PT_LOAD']
            self.dynamic = {t.entry.d_tag: t.entry.d_val for s in e.iter_segments()
                            if s.header['p_type'] == 'PT_DYNAMIC' for t in s.iter_tags()}
            self.dynsymbols = [s.name for s in e.get_section_by_name('.dynsym').iter_symbols()]
            got_section = e.get_section_by_name('.got')
            self.got_section = dict(got_section.header)
            self.text = dict(e.get_section_by_name('.text').header)
        self.md = Cs(CS_ARCH_MIPS, CS_MODE_MIPS32 | CS_MODE_LITTLE_ENDIAN)
        self.md.skipdata = True
    def offset(self, va):
        for s in self.segs:
            if s['p_vaddr'] <= va < s['p_vaddr'] + s['p_filesz']:
                return s['p_offset'] + va - s['p_vaddr']
        raise ValueError(hex(va))
    def va(self, offset):
        for s in self.segs:
            if s['p_offset'] <= offset < s['p_offset'] + s['p_filesz']:
                return s['p_vaddr'] + offset - s['p_offset']
        raise ValueError(hex(offset))
    def code(self, va, size):
        o = self.offset(va)
        return list(self.md.disasm(self.data[o:o+size], va))
    def symbol(self, name):
        return self.syms[name]['st_value']
    def function(self, name):
        s = self.syms[name]
        return self.code(s['st_value'], s['st_size'])
    def got(self, name):
        index = self.dynsymbols.index(name)
        if index < self.dynamic['DT_MIPS_GOTSYM']:
            g=self.got_section
            words=struct.unpack_from('<%dI' % (g['sh_size']//4), self.data, g['sh_offset'])
            matches=[j for j,w in enumerate(words) if w == self.symbol(name)]
            assert len(matches)==1, (name,matches)
            return g['sh_addr']+matches[0]*4
        return self.dynamic['DT_PLTGOT'] + 4 * (self.dynamic['DT_MIPS_LOCAL_GOTNO'] + index - self.dynamic['DT_MIPS_GOTSYM'])

def normalized(i):
    args = i.op_str
    # GP-relative global/GOT references and branch targets relocate. Other
    # displacements (session/HTTP structure offsets, stack sizes) are retained.
    if '$gp' in args:
        args = re.sub(r'-?0x[0-9a-f]+|(?<![a-z0-9])\d+(?![a-z0-9])', '#', args)
    elif i.mnemonic in ('bal', 'jal', 'b', 'beq', 'bne', 'beqz', 'bnez', 'bgez', 'bgtz', 'blez', 'bltz'):
        args = re.sub(r'0x[0-9a-f]+$', '@', args)
    elif i.mnemonic == 'addiu' and args.split(', ')[1] not in ('$sp', '$zero'):
        args = re.sub(r'-?0x[0-9a-f]+$', '#', args)
    return i.mnemonic + ' ' + args

def sequence(code):
    out=[normalized(i) for i in code]
    for k,i in enumerate(code[:-1]):
        following=code[k+1:k+3]
        if i.mnemonic=='addiu' and i.op_str.startswith('$v0, $zero, ') and all(j.mnemonic=='sw' for j in following) and any(j.op_str=='$v0, 0x10($sp)' for j in following):
            out[k]='debug_source_line $v0'
    return out

def main():
    old = Image(PROJECT/'work/ax1800m-firmware-research/extracted/vendor-ax_202610081657/sdDongle')
    new = Image(R/'yunlian-extracted/usr/bin/sdDongle')
    byaddress = {s['st_value']: n for n, s in old.syms.items()}
    src = (PROJECT/'work/ax1800m-firmware-research/AX1800M-Leon-MU1447-October-v0.2/src/altscreen.c').read_text()
    addresses = set(int(s, 16) for s in re.findall(r'0x([0-9a-fA-F]{6})(?:u)?\b', src))
    addresses -= {0xffffff}  # literal mask, not a pointer
    mapping, evidence = {}, []
    for a in sorted(addresses):
        if a in byaddress:
            n = byaddress[a]
            assert n in new.syms, n
            mapping[a] = new.symbol(n)
            evidence.append({'old':hex(a), 'new':hex(mapping[a]), 'method':'exact_export_name', 'symbol':n})
    # Constants may have multiple identical immutable CFString instances.
    # Any byte-identical CFString object has the same value/type semantics.
    for a in sorted(addresses - mapping.keys()):
        if a == 0x56526c: continue
        o = old.offset(a)
        prefix = 8 if old.data[o:o+2] == b'\x56\x07' else 0
        end = old.data.index(b'\0', o+prefix)
        key = old.data[o:end+1]
        if prefix == 0 and (not key[:-1] or not all(32 <= c < 127 for c in key[:-1])): continue
        positions = []; pos = new.data.find(key)
        while pos >= 0:
            if pos % 4 == o % 4: positions.append(pos)
            pos = new.data.find(key, pos+1)
        assert positions, (hex(a), key)
        mapping[a] = new.va(positions[0])
        evidence.append({'old':hex(a), 'new':hex(mapping[a]), 'method':'identical_immutable_constant',
                         'bytes_hex':key.hex(), 'equivalent_instances':len(positions)})
    got = new.got('AirPlayReceiverSessionSetup')
    assert struct.unpack_from('<I', new.data, new.offset(got))[0] == new.symbol('AirPlayReceiverSessionSetup')
    mapping[0x56526c] = got
    evidence.append({'old':'0x56526c','new':hex(got),'method':'MIPS_GOTSYM_and_verified_initial_value'})
    # Two private helpers: search all aligned instructions, preserving the
    # complete non-relocating instruction sequence and structure offsets.
    allcode = new.code(new.text['sh_addr'], new.text['sh_size'])
    norm = sequence(allcode)
    for a, size in [(0x470224, 0x134), (0x4718d4, 0x100)]:
        sig = sequence(old.code(a,size))
        matches = [i for i in range(len(norm)-len(sig)+1) if norm[i:i+len(sig)] == sig]
        assert len(matches) == 1, (hex(a),len(matches))
        mapping[a] = allcode[matches[0]].address
        evidence.append({'old':hex(a),'new':hex(mapping[a]),'method':'unique_normalized_instruction_sequence',
                         'instruction_count':len(sig)})
    assert addresses == mapping.keys(), [hex(a) for a in addresses-mapping.keys()]
    # March has a different property implementation. Do NOT transplant the
    # October enabledFeatures/cornerMasks inline patches. Echo supported
    # offered session features in our SETUP wrapper instead.
    b=0x43d834
    nf=new.function('airPlayGetPropertyFromNativeHU')
    at=next(k for k,i in enumerate(nf) if i.address==b)
    assert nf[at].mnemonic=='beqz' and nf[at].op_str=='$s0, 0x43d850'
    assert nf[at+1].mnemonic=='lw' and nf[at+2].mnemonic=='lw'
    gp=0x56e130
    disp=struct.unpack('<h',nf[at+2].bytes[:2])[0]
    call=struct.unpack_from('<I',new.data,new.offset(gp+disp))[0]
    assert call==new.symbol('CFArrayRemoveValueAtIndex')
    assert nf[at+4].mnemonic=='jalr' and nf[at+4].op_str=='$t9'
    patches=[{'old':'0x43e424','new':hex(b),'function':'airPlayGetPropertyFromNativeHU',
              'method':'semantic_branch_before_verified_CFArrayRemoveValueAtIndex',
              'old_word':hex(struct.unpack_from('<I',new.data,new.offset(b))[0])}]
    # One internal direct call bypasses the GOT hook. Locate and audit its
    # surrounding code, including the stock setup symbol target.
    callmatches = [i for i,x in enumerate(allcode) if x.mnemonic=='bal' and x.op_str==hex(new.symbol('AirPlayReceiverSessionSetup'))]
    oldsig=sequence(old.code(0x469950-24,52))
    callmatches=[i for i in callmatches if norm[i-6:i+7]==oldsig]
    assert len(callmatches)==1,callmatches
    patches.append({'old':'0x469950','new':hex(allcode[callmatches[0]].address),
                    'instruction_window':13,'old_word':hex(struct.unpack_from('<I',new.data,new.offset(allcode[callmatches[0]].address))[0])})
    report={'mapping':{hex(k):hex(v) for k,v in sorted(mapping.items())},'evidence':evidence,'inline_patches':patches,
            'runtime_qualified':False,'baseline':'AX1800/yunlian ax_202603120932'}
    (R/'PORT-MAP.json').write_text(json.dumps(report,indent=2)+'\n')
    print('PORT_MAP addresses=%d patches=%d runtime_qualified=0' % (len(mapping),len(patches)))
if __name__=='__main__':main()
