# Source and rebuilding

Native proxy source: kamgurgul/mib2q-carplay, pinned commit **cf8ab2effb24292025e7648bb79244fed3805741**:
https://github.com/kamgurgul/mib2q-carplay/tree/cf8ab2effb24292025e7648bb79244fed3805741/dongle/hw301

source/cluster_dual.c is unchanged upstream source. GPL-3.0 is included. Local packaging/helpers/tests are supplied under GPL-3.0. Vendor binaries remain prebuilt proprietary inputs; this does not relicense them or claim vendor source is included.

Build defines: CLUSTER_STEP=3, CLUSTER_ADVERT=3, STEP_DECRYPT=1, CLUSTER_DIAG=1, CLUSTER_RGD=0. SONAME libCoreUtils.so; dependencies original libCoreUtilsReal.so and musl libc. Original CoreUtils SONAME changes via patchelf; other OEM files are retained. Raw video dumping is not enabled by default.

The v126/v129 AirPlay library bytes match; other ABI surfaces differ, so the complete v129 app is used. The cross-base symbol-name comparison is retained. New imported names are not necessarily unresolved, since bundled v129 libraries provide many. Actual target rootfs/loader compatibility remains unverified.

Run `sh rebuild.sh` with Docker. Internet is needed to obtain compiler/tool images unless cached; firmware/source inputs are included. Output runs Linux ARM hard-float/musl, not QNX. Docker is not needed to upload.

Compiler image: muslcc/x86_64:arm-linux-musleabihf, digest sha256:2abb44c0efdb11599b9d5d41474c6284e9bccd39a61e9d54427693280abe3bce. Image-tool Dockerfile uses Alpine 3.20, squashfs-tools, patchelf, binutils and Python.

Build verifies four stock ABI hashes, compiles the shim, changes the original SONAME, packs SquashFS/USTAR, and verifies extracted hashes. Timestamps/tool versions may change the output hash; this is not a byte-identical reproducibility claim. A rebuilt image needs its own reviewed IMAGES.json entry before the uploader accepts it. Rebuild never flashes.

Host C tests compile tests/seat_adapter_test.c with tests/hw301_cf_stub.h, -std=gnu11 -O1 -Wall -Wextra -Werror -Wno-unused-function -DMSG_NOSIGNAL=0 -fsanitize=address,undefined. They test protocol ownership, metadata, controls and failure handling with doubles, not actual device cryptography/rendering. Python tests/test_updater.py and tests/test_recovery.py use loopback HTTP/synthetic flash, never hardware; create tmp/ and out/ first.

Included tools/xfel was compiled with Apple clang on ARM64 from all top-level/chips C files, statically linked libusb 1.0.27 and macOS IOKit/CoreFoundation/Security frameworks. libusb was configured --disable-shared --enable-static with a local prefix. Complete release sources/licenses are included under third-party/.

https://github.com/xboot/xfel/releases/tag/v1.4.0
https://github.com/libusb/libusb/releases/tag/v1.0.27

The reference local OTA path requires no signing key or bootloader exploit. Acceptance and boot on this exact adapter are still untested.
