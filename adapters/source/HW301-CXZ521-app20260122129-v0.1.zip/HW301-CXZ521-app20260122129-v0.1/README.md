## Required vehicle test and fresh phone pairing

A bench/computer may be used for upload and build verification. Functional acceptance MUST be tested in the actual compatible car, with its working head unit and Virtual Cockpit. A bench unit without the cockpit can produce misleading black-screen/no-map results.

After flashing reports completion and the documented reboot/power cycle is finished, remove the OLD adapter pairing from the iPhone: Settings > Bluetooth > the adapter > Forget This Device; also Settings > General > CarPlay > the matching adapter/car entry > Forget This Car if that entry exists. Do not erase unrelated pairings. Then connect the adapter in the parked car and pair it again as a new connection, with Bluetooth and Wi-Fi enabled, approving CarPlay. Old pairing/cache state can prevent correct connection after an update.

Verify centre-screen video/audio first, then cockpit maps, app-supported zoom, disconnect/reconnect and OEM return. A version string or retained build marker alone is not a car test. Fresh pairing does not cure wrong hardware/firmware. Collect logs before a restart/rollback if it fails.

# CXZ521 / HW301 SEAT MU1409 adapter candidate v0.1

**Highly experimental. No adapter boot, flash, physical recovery or vehicle test has been performed. Use at your own risk, without warranty or liability for damage or lost pairing.** This kit was built locally; nothing has been flashed.

## What this image does

The earlier A/B tests showed wireless main CarPlay works when the auxiliary descriptor is omitted, but fails even with a minimal auxiliary descriptor. This candidate uses kamgurgul's native HW301 second-screen proxy: hide the extra display from the stock single-screen parser, negotiate a separate authenticated Type-111 stream, and relay its video. It preserves the head unit's geometry, SafeAreas and zoomFactor without decoding/resizing/re-encoding.

It contains the complete vendor **v129 app partition**, plus a compiled CoreUtils shim. It does not patch v126 private ABI offsets. Your reported HW301_20250630126 and Cxzconverter branding match the stock-v126 reference, but your PCB, actual flash layout, private pairing ABI and rootfs have not been verified. Identification strings alone cannot guarantee compatibility. The uploader rejects unmatched app bases.

Only four app paths change relative to stock v129: the replacement CoreUtils, renamed original CoreUtils and two web build markers. The separate RGD/iAP2 guidance bridge is disabled; ETA/directions within phone-rendered video still depend on the existing receiver/phone. No head-unit software is included. Keep the restored, working SEAT receiver; do not install the upstream Audi/MHI2Q head-unit package.

## Bench installation — Mac Terminal, NOT car SSH

Power the adapter from the Mac, disconnected from the car. Python 3.12+ is required; adapter.sh selects your existing Codex Python automatically. No Internet is needed after download. Allow approximately 3–10 minutes for connecting, upload, writing and verification, depending on speed.

Open Terminal in the extracted kit folder:

```sh
sh adapter.sh dry-run
```

This checks both firmware files offline with zero device writes. Join **Cxzconverter_e19f** using Mac Wi-Fi; reference password **88888888** if requested. Then:

```sh
sh adapter.sh probe
sh adapter.sh flash
```

Probe only reads identification. Flash explicitly uploads and advances the local vendor flash writer. Keep power connected. Require FLASH=100% and FLASH_REPORTED_COMPLETE=1. A progress reset, rejection, timeout or dropped connection is not success: retain power, save the output and do not blindly repeat the flash.

After reported completion, wait 10 seconds, power-cycle the adapter on the bench, reconnect Wi-Fi, then:

```sh
sh adapter.sh verify
```

Expected build marker: seat-mu1409-cxz521-native-v0.1-20261029. The vendor UI can show **HW301_20260122129**; the marker distinguishes the custom build. The OTA envelope number 2129 is not the UI version. Default address is your observed 192.168.31.1. If the SSID/IP changes (upstream reference: smartBox / 192.168.5.1), use the actual adapter gateway with `--host`, for example `sh adapter.sh verify --host 192.168.5.1`.

## Vehicle qualification after bench verification

Connect to the parked car, establish wireless CarPlay and verify the centre screen first, then navigation in the cockpit. Independently check zoom where supported by the app, menu settings, stop/reconnect and OEM navigation return. Actual 110/111 SETUP handling still needs vehicle qualification. No SD installer is needed for this kit.

Mac SSH command after separately joining car Wi-Fi:

```sh
ssh -o ControlPath=none -o HostKeyAlgorithms=+ssh-rsa root@192.168.50.242
```

Read-only commands in car SSH:

```sh
grep -E 'SETUP|TEARDOWN|GEN2 /info ready' /tmp/altscreen111.log | tail -80
cat /tmp/mibr-alt111-gen2.status
/bin/ksh /mnt/app/root/altscreen-u2/scripts/direct_ts_auto_status.sh
```

Adapter diagnostics later, on the bench connected to its Wi-Fi:

```sh
sh adapter.sh logs --out logs
```

This creates/downloads a local log archive, with no vendor upload. Review session/network identifiers before sharing. collect-car.sh is the existing read-only car collector; consult its header before use.

## Rollback

While the adapter Wi-Fi/web updater responds:

```sh
sh adapter.sh rollback
```

After reported 100%, wait 10 seconds, power-cycle, reconnect Wi-Fi, then:

```sh
sh adapter.sh verify-stock
```

This restores the included stock-v126 app and checks the reported version. It is a vendor image, not an individual-device backup, and does not guarantee pairing/configuration preservation. If the AP/updater will not start, see RECOVERY.md. Recovery requires opening the adapter and is not guaranteed.

## Evidence and limits

Passed locally: ARM hard-float compilation, pinned reference ABI/import checks, SquashFS/OTA round-trip hashes, sanitizer-backed host protocol tests, SEAT geometry/three-SafeArea/zoomFactor-70 passthrough, seven simulated updater tests and four synthetic recovery tests. These do not establish target rootfs compatibility, adapter boot, real wireless crypto/session behaviour, actual flashing, physical recovery or visible vehicle operation. See validation/ and BUILD.md.

Native wireless CarPlay directly on MHI2 remains separate incomplete research, not an available enable switch.
