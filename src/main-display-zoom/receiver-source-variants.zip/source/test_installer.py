"""Run only in a disposable container. Real installer and real payload hashes;
mount/process state and platform helper identity are simulated explicitly."""
import hashlib,json,os,pathlib,shutil,subprocess
P=pathlib.Path('/test'); KIT=P/'MU1409-main-display-zoom-v0.1'; B=pathlib.Path('/mnt/app/root/altscreen-u2'); results=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);p.chmod(0o755)
def reset(variant):
 shutil.rmtree('/mnt/app',ignore_errors=True);shutil.rmtree('/fs/tmpfs',ignore_errors=True)
 pathlib.Path('/fs/tmpfs').mkdir(parents=True);(B/'bin').mkdir(parents=True);(B/'harman-r13').mkdir();(B/'harman-r13/enabled').touch()
 pathlib.Path('/mnt/app/eso/lib').mkdir(parents=True)
 for f in [B/'bin/libaltscreen111.so',pathlib.Path('/mnt/app/eso/lib/libmibr_carplay111.so')]:shutil.copy(P/variant/'payload/libmibr_carplay111.so',f)
 pathlib.Path('/mnt/app/eso/lib/libairplay.so').write_text('platform identity fixture')
 put(B/'bin/sha256sum', '''#!/bin/sh
case "$1" in
*/bin/sha256sum) echo '95d1e6e9611905d9f91f020d34b1bcd1236085c2862dee3faf0a91e790d37f3c  helper';;
/mnt/app/eso/lib/libairplay.so) echo '193a4fd9101ec2aa05e7159cfa307b96500810d379ca74a194f172adc13a46b5  stock';;
*) /usr/bin/sha256sum "$1";;esac
''')
 shutil.rmtree('/mock-bin',ignore_errors=True)
 put(pathlib.Path('/mock-bin/mount'),'#!/bin/sh\necho "$*" >> /fs/tmpfs/mount.log\n')
 put(pathlib.Path('/mock-bin/sync'),'#!/bin/sh\nexit 0\n')
 put(pathlib.Path('/mock-bin/pidin'),'#!/bin/sh\nif [ "${ZOOM_TEST_CONNECTED:-0}" = 1 ];then echo "123 /eso/bin/apps/dio_manager";else echo "1 procnto";fi\n')
 put(pathlib.Path('/mock-bin/mv'),'''#!/bin/sh
if [ "${ZOOM_TEST_FAIL_COMMIT:-0}" = 1 ] && [ "$1" = /mnt/app/root/altscreen-u2/bin/libaltscreen111.so.mainzoom-new ] && [ ! -e /fs/tmpfs/failed-once ];then touch /fs/tmpfs/failed-once;exit 1;fi
exec /bin/mv "$@"
''')
def run(mode,ok=True,**kw):
 env=dict(os.environ,PATH='/mock-bin:/usr/bin:/bin',**kw)
 r=subprocess.run(['/opt/qnx650/host/linux/x86/usr/bin/ksh',str(KIT/'install.sh'),mode],env=env,text=True,capture_output=True)
 assert (r.returncode==0)==ok,(mode,r.returncode,r.stdout,r.stderr)
 return r.stdout
def hashes():return [sha(pathlib.Path('/mnt/app/eso/lib/libmibr_carplay111.so')),sha(B/'bin/libaltscreen111.so')]
for variant in ['baseline','legacy-baseline']:
 reset(variant);orig=hashes();assert len(set(orig))==1
 run('--check');assert hashes()==orig and not (B/'backup').exists()
 run('--apply');candidate=hashes();assert len(set(candidate))==1 and candidate!=orig
 run('--apply');assert hashes()==candidate
 run('--restore-check');assert hashes()==candidate
 run('--restore');assert hashes()==orig
 run('--restore');assert hashes()==orig
 run('--apply');assert hashes()==candidate
 assert pathlib.Path('/fs/tmpfs/mount.log').read_text().splitlines()[-1]=='-ur /mnt/app'
 results.append(variant+': check/apply/repeat/restore/reapply PASS')
reset('baseline');orig=hashes();out=run('--apply',False,ZOOM_TEST_FAIL_COMMIT='1');assert 'ROLLED_BACK' in out and hashes()==orig
assert pathlib.Path('/fs/tmpfs/mount.log').read_text().splitlines()[-1]=='-ur /mnt/app'
results.append('second_commit_failure: both original files restored and mount returned readonly PASS')
reset('baseline');run('--apply',False,ZOOM_TEST_CONNECTED='1');assert not (B/'backup').exists();results.append('connected_phone: refused before writes PASS')
reset('baseline');pathlib.Path('/mnt/app/eso/lib/libmibr_carplay111.so').write_text('unknown');run('--check',False);results.append('unknown_receiver: refused PASS')
reset('baseline');t=B/'bin/libaltscreen111.so';t.unlink();t.symlink_to('/mnt/app/eso/lib/libmibr_carplay111.so');run('--apply',False);results.append('symlink_target: refused PASS')
reset('baseline');run('--apply');(B/'backup/main-display-zoom-v01/0').write_text('bad backup');run('--restore',False);results.append('damaged_backup: refused PASS')
out={'scope':'host simulations only; no vehicle execution','results':results,'pass':True}
(P/'INSTALLER-TESTS.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
