# rc1.3 backup-seal correction

- Write the native verifier’s required two-space hash/path separator for saved files and backup metadata.
- Tighten the host manifest fixture to reject the original malformed format.
- Exercise the actual ARM parser with fixture file/libc APIs.
- Add explicit --recover-backup for an unfinished pre-write backup: verify saved hashes and every live baseline, then retain it under .preseal-rc12. No checksum bypass or automatic deletion.
- Runtime binaries, target list and normal rollback format are unchanged.
