# rc1.1 installer correction

- Calculate RAM staging from each source file, allocation rounding, generated-file growth and duplicate JAR aliases.
- Add 8 MiB staging reserve; retain independent 30 MB persistent-volume checks.
- Print available and required bytes before staging.
- Add host regression cases for the reported 19,956 KiB free RAM disk and insufficient RAM.
- No runtime binaries, Java patches, zoom, safe areas or ETA settings changed. A failed rc1 space preflight made no persistent changes.
